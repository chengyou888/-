# Unlock OpenAI Computer Use with Codex++

A Codex++ tweak that enables Codex Desktop's bundled OpenAI Computer Use MCP server as `computer-use`.

No clone. No replacement automation engine. No third-party desktop controller.

This tweak wires Codex++ into OpenAI's own bundled `SkyComputerUseClient`, then gives you a native-style Computer Use settings page inside Codex.

## What It Does

OpenAI Computer Use lets Codex click, type, and navigate Mac apps.

This tweak makes that available through Codex++ when the official helper is already bundled inside your Codex Desktop app, even if Codex does not expose the native Computer Use UI for your account or region.

It adds:

- `computer-use` MCP server registration through Codex++ managed MCP
- Native bundled `computer-use@openai-bundled` plugin enablement
- Native Computer Use sidebar icon and native-style settings page
- Native desktop feature registration nudge for Codex's own bundled-plugin reconciler
- Plugin status using Codex Desktop's bundled Computer Use metadata
- Always-allowed app management
- Click sound controls
- Startup self-healing when Codex rewrites the temporary bundled marketplace without `computer-use`
- `Troubleshoot` section for repair, diagnostics, macOS permission panes, official Codex update/install recovery, runtime marketplace restore, and local plugin cache install
- Support for both `Codex.app` and `Codex (Beta).app`

## Important

This tweak uses OpenAI's official local Computer Use helper. It does not ship a clone, replacement engine, or third-party desktop controller.

When the helper is missing, `Repair` and `doctor.sh` try Codex's official update/install flow and then re-check these locations:

```text
/Applications/Codex.app/Contents/Resources/plugins/openai-bundled/plugins/computer-use
/Applications/Codex (Beta).app/Contents/Resources/plugins/openai-bundled/plugins/computer-use
```

Once the helper exists, the tweak also installs Codex's local plugin cache from that official bundle:

```text
~/.codex/plugins/cache/openai-bundled/computer-use/<version>
```

It also enables Codex's native bundled plugin flag:

```toml
[plugins."computer-use@openai-bundled"]
enabled = true
```

Codex may rewrite its temporary bundled marketplace at launch. In unsupported-region states that generated marketplace can omit `computer-use`. The tweak restores the official bundled Computer Use entry in the runtime marketplace automatically on startup, so you should not need to press `Repair` after every restart.

Codex also keeps an in-memory desktop feature availability state. In unsupported-region states, that state can tell the native app that Computer Use is unavailable even after the files and config are correct. The tweak sends Codex's own desktop feature-change IPC after startup with only these two fields enabled:

```text
computerUse = true
computerUseNodeRepl = true
```

That is what lets Codex's native bundled-plugin reconciler see and register the official `computer-use` plugin instead of hiding it.

If OpenAI's official Codex build still does not contain the helper after the updater/installer runs, the tweak stops. It will not fetch or redistribute OpenAI's signed helper from unofficial sources.

## Requirements

- macOS
- Codex Desktop
- Codex++ installed and enabled
- A Codex build that includes the bundled `computer-use` plugin

## Install

Clone this repo into your Codex++ tweaks folder:

```sh
cd "$HOME/Library/Application Support/codex-plusplus/tweaks"
git clone https://github.com/TheAndersMadsen/codex-plusplus-computer-use.git
chmod +x codex-plusplus-computer-use/computer-use-mcp.sh
chmod +x codex-plusplus-computer-use/doctor.sh
```

Then reload Codex++ tweaks or fully quit and reopen Codex.

## Setup

Open:

```text
Codex Settings -> Tweaks -> Computer Use
```

You should see:

- `Plugin` showing `Installed`
- `Always-allowed apps`
- Click sound dropdown
- `Troubleshoot`

If setup is incomplete, open `Troubleshoot` and click `Repair`.

Repair will:

- Check stable and beta Codex app bundles
- Run Codex's official updater if Computer Use is missing
- Open Codex's official app installer flow if the update still does not provide the helper
- Install the local Codex plugin cache from the official bundled helper
- Restore `computer-use` in Codex's temporary runtime bundled marketplace
- Re-register the bundled `openai-bundled` marketplace
- Enable the native `computer-use@openai-bundled` plugin flag
- Nudge Codex's native desktop feature availability so its own plugin reconciler can include Computer Use
- Re-check the `computer-use` MCP server registration

After repair, fully quit and reopen Codex.

## Grant macOS Permissions

Computer Use needs:

- Accessibility
- Screen Recording, sometimes called `Screen & System Audio Recording`

In `Troubleshoot`, use the `Accessibility` and `Screen Recording` buttons to open the right System Settings panes.

Grant permissions to `Codex Computer Use`.

If it still does not work, also grant the same permissions to:

```text
/Applications/Codex.app
/Applications/Codex (Beta).app
```

If `Codex Computer Use` does not appear in System Settings, open it once:

```sh
open "/Applications/Codex.app/Contents/Resources/plugins/openai-bundled/plugins/computer-use/Codex Computer Use.app" 2>/dev/null || \
open "/Applications/Codex (Beta).app/Contents/Resources/plugins/openai-bundled/plugins/computer-use/Codex Computer Use.app"
```

Then check System Settings again.

## Test It

Open a fresh Codex thread and ask:

```text
Use Computer Use to open Calculator and type 2+2.
```

If Computer Use is loaded correctly, Codex should either start the desktop-control flow or ask for approval/permissions.

## App Mentions

If native app mentions are available in your Codex build, apps should appear in the `@` menu after:

- `Repair` has completed
- Codex Desktop has been fully restarted with `Cmd+Q`
- A fresh thread has been opened

Use the real app name. For example, if your browser is Helium, use `@Helium`, not `@Chrome`.

If the `@` menu still only shows files, Computer Use can still be loaded through the MCP server. Ask directly:

```text
Use Computer Use with Helium to open example.com.
```

The app mention picker itself is native Codex UI. This tweak enables the local OpenAI helper and native plugin config, but it does not replace Codex's internal composer/autocomplete implementation.

The tweak now also nudges Codex's native Computer Use feature availability after startup. If the native app still does not show app suggestions after that, the remaining blocker is inside Codex's private composer/autocomplete implementation rather than the Computer Use MCP registration.

## Troubleshooting

From the settings page, use:

- `Repair` to re-register the bundled marketplace and MCP server
- `Repair` also runs Codex's official update/install flow if the bundled helper is missing
- `Details` to see which setup checks are passing
- `Accessibility` and `Screen Recording` to jump to macOS permissions

You can also run the doctor manually:

```sh
cd "$HOME/Library/Application Support/codex-plusplus/tweaks/codex-plusplus-computer-use"
./doctor.sh
```

The doctor checks:

- Stable and beta Codex app bundles
- The bundled OpenAI `computer-use` plugin
- OpenAI's signed `SkyComputerUseClient`
- Codex's official updater/installer if the helper is missing
- The local Codex plugin cache under `~/.codex/plugins/cache/openai-bundled/computer-use`
- Codex's temporary bundled marketplace under `~/.codex/.tmp/bundled-marketplaces/openai-bundled`
- Codex's local `openai-bundled` marketplace
- The native `computer-use@openai-bundled` plugin enable flag
- Codex++ managed MCP registration

## Update

```sh
cd "$HOME/Library/Application Support/codex-plusplus/tweaks/codex-plusplus-computer-use"
git pull
chmod +x computer-use-mcp.sh doctor.sh
```

Reload Codex++ tweaks or restart Codex afterward.

## Uninstall

```sh
rm -rf "$HOME/Library/Application Support/codex-plusplus/tweaks/codex-plusplus-computer-use"
codex mcp remove computer-use
```

Then reload Codex++ tweaks or restart Codex.

## What This Is Not

- Not a Computer Use clone
- Not a replacement desktop automation engine
- Not a server-side account unlock
- Not an unofficial mirror of OpenAI's signed Computer Use helper

It is a Codex++ tweak that exposes OpenAI's local helper bundled with Codex Desktop, can ask Codex's official updater/installer to fetch a build that includes it, and installs Codex's local plugin cache from that official bundle.

## Manifest

```json
{
  "id": "co.bennett.computer-use",
  "name": "OpenAI Computer Use",
  "version": "0.4.5",
  "githubRepo": "TheAndersMadsen/codex-plusplus-computer-use",
  "scope": "both",
  "main": "index.js",
  "mcp": {
    "command": "./computer-use-mcp.sh"
  }
}
```

## License

MIT
