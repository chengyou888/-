/**
 * OpenAI Computer Use
 *
 * Registers Codex Desktop's bundled OpenAI Computer Use MCP server through
 * Codex++ managed MCP support and provides a setup/repair page.
 */

const TWEAK_ID = "co.bennett.computer-use";
const MARKETPLACE_NAME = "openai-bundled";
const APP_CANDIDATES = [
  "/Applications/Codex.app",
  "/Applications/Codex (Beta).app",
];
const MARKETPLACE_REL = "Contents/Resources/plugins/openai-bundled";
const PLUGIN_REL = `${MARKETPLACE_REL}/plugins/computer-use`;
const CLIENT_REL = `${PLUGIN_REL}/Codex Computer Use.app/Contents/SharedSupport/SkyComputerUseClient.app/Contents/MacOS/SkyComputerUseClient`;
const PLUGIN_JSON_REL = `${PLUGIN_REL}/.codex-plugin/plugin.json`;
const MARKETPLACE_JSON_REL = `${MARKETPLACE_REL}/.agents/plugins/marketplace.json`;
const PLUGIN_CONFIG_SECTION = 'plugins."computer-use@openai-bundled"';
const STARTUP_REPAIR_DELAYS_MS = [0, 1500, 6000, 15000, 30000, 60000];
const FEATURE_NUDGE_DELAYS_MS = [2500, 6000, 12000, 25000, 60000];
const COMPUTER_USE_STATSIG_GATE = "1506311413";
const APP_PROTOCOL_SCHEME = "app";
const STATSIG_ASSET_RE = /\/assets\/statsig-[^/]+\.js$/;
const DESKTOP_MESSAGE_CHANNEL = "codex_desktop:message-from-view";
const APPROVALS_GROUP_CONTAINER = "2DC432GLL2.com.openai.sky.CUAService";
const APPROVALS_REL = [
  "Library",
  "Group Containers",
  APPROVALS_GROUP_CONTAINER,
  "Library",
  "Application Support",
  "Software",
  "ComputerUseAppApprovals.json",
];
const SOUND_DEFAULTS_DOMAIN = "com.openai.sky.CUAService";
const SOUND_DEFAULTS_KEY = "computerUseSoundMode";
const SOUND_MODES = [
  {
    value: "foregroundClicks",
    label: "Play sounds for foreground clicks",
  },
  {
    value: "foregroundAndBackgroundClicks",
    label: "Play sounds for foreground and background clicks",
  },
  {
    value: "off",
    label: "Don't play sounds",
  },
];

/** @type {import("@codex-plusplus/sdk").Tweak} */
module.exports = {
  start(api) {
    if (api.process === "main") {
      this._mainTeardown = startMain(api);
      return;
    }

    this._rendererTeardown = startRenderer(api);

    if (typeof api.settings?.registerPage === "function") {
      this._settingsHandle = api.settings.registerPage({
        id: "computer-use",
        title: "Computer Use",
        iconSvg: computerUseIconSvg(),
        render(root) {
          renderSetupPage(root, api);
        },
      });
      return;
    }

    if (typeof api.settings?.register === "function") {
      this._settingsHandle = api.settings.register({
        id: "computer-use",
        title: "OpenAI Computer Use",
        description:
          "Unlocks OpenAI's bundled Computer Use MCP server as computer-use.",
        render(root) {
          renderSetupPage(root, api);
        },
      });
    }
  },

  stop() {
    this._settingsHandle?.unregister?.();
    this._settingsHandle = null;
    this._rendererTeardown?.();
    this._rendererTeardown = null;
    this._mainTeardown?.();
    this._mainTeardown = null;
  },
};

function computerUseIconSvg() {
  return [
    '<svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="icon-sm inline-block align-middle" aria-hidden="true">',
    '<path d="M11.2878 9.46029L11.4421 9.49545L17.8913 11.43L18.0642 11.4974C18.8215 11.8649 18.8705 12.9544 18.1491 13.388L17.9821 13.4701L15.1872 14.5872L14.07 17.3822C13.7134 18.2734 12.4912 18.2756 12.0974 17.4642L12.03 17.2913L10.0954 10.8421C9.8634 10.0687 10.5245 9.34418 11.2878 9.46029ZM13.0984 16.2288L13.9929 13.9954L14.0388 13.8949C14.1579 13.6675 14.3549 13.4891 14.5954 13.3929L16.8288 12.4984L11.5007 10.9007L13.0984 16.2288ZM6.50362 12.9749C6.76326 12.7153 7.18434 12.7154 7.44405 12.9749C7.70375 13.2346 7.70375 13.6557 7.44405 13.9154L5.67648 15.6829C5.41678 15.9426 4.99574 15.9426 4.73605 15.6829C4.47652 15.4232 4.4764 15.0022 4.73605 14.7425L6.50362 12.9749ZM3.43722 7.3265L5.85226 7.97299L5.97823 8.02084C6.25482 8.1591 6.40594 8.47712 6.32296 8.78744C6.23981 9.09774 5.94995 9.298 5.64132 9.27963L5.50851 9.25814L3.09347 8.61068L2.96749 8.56283C2.6908 8.42452 2.53958 8.10666 2.62276 7.79623C2.70597 7.4859 2.99571 7.28652 3.3044 7.30502L3.43722 7.3265ZM15.447 4.05111C15.7051 3.88059 16.0556 3.90894 16.2829 4.13607C16.5426 4.39577 16.5426 4.8168 16.2829 5.0765L14.5153 6.84408C14.2556 7.10378 13.8346 7.10378 13.5749 6.84408C13.3154 6.58437 13.3153 6.16329 13.5749 5.90365L15.3425 4.13607L15.447 4.05111ZM8.3962 2.02279C8.75096 1.92773 9.1156 2.13874 9.21065 2.49349L9.85812 4.90853L9.8796 5.04135C9.89797 5.34998 9.69771 5.63984 9.38741 5.72299C9.07711 5.80592 8.75905 5.65484 8.62081 5.37826L8.57296 5.25228L7.92648 2.83724L7.90499 2.70443C7.8865 2.39577 8.08593 2.10603 8.3962 2.02279Z" fill="currentColor"/>',
    '</svg>',
  ].join("");
}

function startMain(api) {
  const { ipcMain } = require("electron");
  const startupRepairTimers = scheduleStartupRepair(api);
  const uninstallStatsigAssetPatch = installStatsigAssetPatch(api);
  const channels = [
    ["setup-status", () => getSetupStatus()],
    ["repair-setup", () => repairSetup(api)],
    ["native-settings", () => getNativeSettings()],
    ["native-feature-nudge", (_payload, event) => nudgeNativeComputerUseFeatureFromMain(api, event)],
    ["remove-approved-app", ({ bundleIdentifier }) => removeApprovedApp(bundleIdentifier)],
    ["write-sound-mode", ({ value }) => writeSoundMode(value)],
    ["open-permission-settings", ({ pane }) => openPermissionSettings(pane)],
  ];

  for (const [name, handler] of channels) {
    const channel = `codexpp:${TWEAK_ID}:${name}`;
    ipcMain.removeHandler(channel);
    ipcMain.handle(channel, async (event, payload = {}) => handler(payload, event));
  }

  api.log.info("OpenAI Computer Use setup page installed.");

  return () => {
    uninstallStatsigAssetPatch?.();
    for (const timer of startupRepairTimers) clearTimeout(timer);
    for (const [name] of channels) {
      ipcMain.removeHandler(`codexpp:${TWEAK_ID}:${name}`);
    }
  };
}

function installStatsigAssetPatch(api) {
  const fs = require("node:fs");
  const path = require("node:path");
  const { app, protocol } = require("electron");
  const timers = [];
  let installed = false;
  let installing = false;

  const tryInstall = () => {
    if (installed || installing) return;
    installing = true;
    try {
      protocol.interceptBufferProtocol(APP_PROTOCOL_SCHEME, (request, respond) => {
        respondAppProtocolRequest({ api, app, fs, path, request, respond });
      }, (error) => {
        installing = false;
        if (error) {
          api.log.debug(`Computer Use Statsig asset patch not installed yet: ${error.message || error}`);
          return;
        }
        installed = true;
        api.log.info("Computer Use Statsig asset patch installed for Codex app:// assets.");
      });
    } catch (error) {
      installing = false;
      api.log.debug("Computer Use Statsig asset patch install failed:", error);
    }
  };

  app.whenReady().then(() => {
    for (const delay of [0, 25, 100, 250, 1000, 2500]) {
      timers.push(setTimeout(tryInstall, delay));
    }
  }).catch((error) => {
    api.log.debug("Computer Use Statsig asset patch scheduling failed:", error);
  });

  return () => {
    for (const timer of timers) clearTimeout(timer);
    if (!installed) return;
    try {
      protocol.uninterceptProtocol(APP_PROTOCOL_SCHEME);
      installed = false;
    } catch (error) {
      api.log.debug("Computer Use Statsig asset patch uninstall failed:", error);
    }
  };
}

function respondAppProtocolRequest({ api, app, fs, path, request, respond }) {
  try {
    const url = new URL(request.url);
    const webviewRoot = path.join(app.getAppPath(), "webview");
    let pathname = decodeURIComponent(url.pathname || "/index.html");
    if (pathname === "/") pathname = "/index.html";

    const relativePath = pathname.replace(/^\/+/, "");
    const filePath = path.resolve(webviewRoot, relativePath);
    const relativeToRoot = path.relative(webviewRoot, filePath);
    if (relativeToRoot.startsWith("..") || path.isAbsolute(relativeToRoot)) {
      respond({ statusCode: 403, mimeType: "text/plain", data: Buffer.from("Forbidden") });
      return;
    }

    fs.readFile(filePath, (error, data) => {
      if (error) {
        respond({ statusCode: 404, mimeType: "text/plain", data: Buffer.from("Not found") });
        return;
      }

      let body = data;
      if (STATSIG_ASSET_RE.test(pathname)) {
        const patch = patchStatsigAsset(data.toString("utf8"));
        if (patch.changed) {
          api.log.info(`Patched Computer Use Statsig gate while serving ${pathname}.`);
          body = Buffer.from(patch.source, "utf8");
        } else {
          api.log.debug(`Computer Use Statsig asset patch skipped for ${pathname}: ${patch.reason}`);
        }
      }

      respond({
        mimeType: mimeTypeForPath(pathname),
        data: body,
      });
    });
  } catch (error) {
    api.log.debug("Computer Use app:// asset response failed:", error);
    respond({ statusCode: 500, mimeType: "text/plain", data: Buffer.from("Internal error") });
  }
}

function patchStatsigAsset(source) {
  const patchedNeedle = `String(e)===${JSON.stringify(COMPUTER_USE_STATSIG_GATE)}`;
  if (source.includes(patchedNeedle)) {
    return { changed: false, source, reason: "already patched" };
  }

  const pattern = /checkGate\((\w+),(\w+)\)\{return this\.getFeatureGate\(\1,\2\)\.value\}/;
  const match = source.match(pattern);
  if (!match) {
    return { changed: false, source, reason: "checkGate pattern was not found" };
  }

  const [needle, gateArg, optionsArg] = match;
  return {
    changed: true,
    source: source.replace(
      needle,
      `checkGate(${gateArg},${optionsArg}){return String(${gateArg})===${JSON.stringify(COMPUTER_USE_STATSIG_GATE)}?!0:this.getFeatureGate(${gateArg},${optionsArg}).value}`
    ),
    reason: "patched",
  };
}

function mimeTypeForPath(filePath) {
  const extension = filePath.split("?")[0].split(".").pop()?.toLowerCase();
  switch (extension) {
    case "html":
      return "text/html";
    case "js":
      return "text/javascript";
    case "css":
      return "text/css";
    case "json":
      return "application/json";
    case "svg":
      return "image/svg+xml";
    case "png":
      return "image/png";
    case "jpg":
    case "jpeg":
      return "image/jpeg";
    case "webp":
      return "image/webp";
    case "woff":
      return "font/woff";
    case "woff2":
      return "font/woff2";
    default:
      return "application/octet-stream";
  }
}

function startRenderer(api) {
  const timers = FEATURE_NUDGE_DELAYS_MS.map((delay) => setTimeout(() => {
    nudgeNativeComputerUseFeature(api, delay);
  }, delay));

  return () => {
    for (const timer of timers) clearTimeout(timer);
  };
}

async function nudgeNativeComputerUseFeature(api, delay) {
  try {
    const result = await api.ipc.invoke("native-feature-nudge");
    if (result?.ok) {
      api.log.debug(`Requested native Computer Use feature availability after ${delay}ms.`);
      return;
    }
    api.log.debug(`Native Computer Use feature nudge skipped after ${delay}ms: ${result?.reason || "unknown"}`);
  } catch (error) {
    api.log.debug("Native Computer Use feature nudge failed:", error);
  }
}

async function nudgeNativeComputerUseFeatureFromMain(api, event) {
  try {
    const { ipcMain } = require("electron");
    const nativeHandler = ipcMain._invokeHandlers?.get?.(DESKTOP_MESSAGE_CHANNEL);
    if (typeof nativeHandler !== "function") {
      return { ok: false, reason: "native desktop message handler was not available" };
    }

    await nativeHandler(event, {
      type: "electron-desktop-features-changed",
      computerUse: true,
      computerUseNodeRepl: true,
    });
    api.log.debug("Forwarded native Computer Use feature availability.");
    return { ok: true };
  } catch (error) {
    api.log.debug("Forwarding native Computer Use feature availability failed:", error);
    return { ok: false, reason: error?.message || String(error) };
  }
}

function scheduleStartupRepair(api) {
  return STARTUP_REPAIR_DELAYS_MS.map((delay) => setTimeout(() => {
    try {
      const result = repairExistingSetup(api);
      if (result.changed) {
        api.log.info(`Computer Use startup repair applied after ${delay}ms: ${result.messages.join(" | ")}`);
      }
    } catch (error) {
      api.log.warn("Computer Use startup repair failed:", error);
    }
  }, delay));
}

function repairExistingSetup(api) {
  const fs = require("node:fs");
  const messages = [];
  const status = getSetupStatus();
  const selectedApp = status.selectedApp;
  if (!selectedApp) {
    return { changed: false, messages: ["Computer Use bundle is not available yet."] };
  }

  const before = JSON.stringify({
    cache: status.pluginCache.ok,
    runtimeMarketplace: status.runtimeMarketplace.ok,
    marketplace: status.marketplace.ok,
    pluginConfig: status.pluginConfig.enabled,
  });

  if (fs.existsSync(status.wrapperPath) && !isExecutable(fs, status.wrapperPath)) {
    fs.chmodSync(status.wrapperPath, 0o755);
    messages.push(`Made launcher executable: ${status.wrapperPath}`);
  }

  ensurePluginCache(selectedApp, messages);
  ensureRuntimeMarketplace(selectedApp, messages);
  ensureMarketplaceRegistration({
    api,
    codexBin: selectedApp.codexBin,
    configPath: status.configPath,
    marketplaceRoot: selectedApp.marketplaceRoot,
    messages,
    backupConfig: false,
  });
  ensurePluginEnabled(status.configPath, messages);

  const next = getSetupStatus();
  const after = JSON.stringify({
    cache: next.pluginCache.ok,
    runtimeMarketplace: next.runtimeMarketplace.ok,
    marketplace: next.marketplace.ok,
    pluginConfig: next.pluginConfig.enabled,
  });
  return { changed: before !== after, messages, status: next };
}

function getSetupStatus() {
  const fs = require("node:fs");
  const path = require("node:path");
  const configPath = path.join(process.env.CODEX_HOME || path.join(process.env.HOME, ".codex"), "config.toml");
  const wrapperPath = path.join(__dirname, "computer-use-mcp.sh");
  const apps = appCandidates().map((app) => inspectApp(app));
  const selectedApp = apps.find((app) => app.usable) || null;
  const configText = safeReadFile(fs, configPath);
  const marketplace = inspectMarketplace(configText, selectedApp);
  const mcp = inspectMcp(configText, wrapperPath);
  const wrapperExecutable = isExecutable(fs, wrapperPath);
  const plugin = selectedApp?.plugin ||
    apps.find((app) => app.plugin)?.plugin ||
    fallbackPluginMetadata();
  const pluginCache = inspectPluginCache(fs, plugin);
  const pluginConfig = inspectPluginConfig(configText);
  const runtimeMarketplace = inspectRuntimeMarketplace(fs, selectedApp);
  const checks = [
    check(
      selectedApp !== null,
      "OpenAI Computer Use bundle",
      selectedApp
        ? `Found in ${selectedApp.app}`
        : "Not found in /Applications/Codex.app or /Applications/Codex (Beta).app"
    ),
    check(
      pluginCache.ok,
      "Computer Use plugin cache",
      pluginCache.detail,
      pluginCache.ok ? "pass" : "fail"
    ),
    check(
      runtimeMarketplace.ok,
      "Runtime bundled marketplace",
      runtimeMarketplace.detail,
      runtimeMarketplace.ok ? "pass" : "fail"
    ),
    check(
      wrapperExecutable,
      "Codex++ MCP launcher",
      wrapperExecutable
        ? wrapperPath
        : `Missing executable bit on ${wrapperPath}`
    ),
    check(
      mcp.registered,
      "Codex MCP server",
      mcp.registered
        ? `computer-use is registered${mcp.command ? `: ${mcp.command}` : ""}`
        : "Codex++ has not written [mcp_servers.computer-use] yet. Reload Codex++ tweaks or restart Codex."
    ),
    check(
      marketplace.ok,
      "Bundled marketplace",
      marketplace.detail,
      marketplace.ok ? "pass" : marketplace.fixable ? "warn" : "fail"
    ),
    check(
      pluginConfig.enabled,
      "Native Computer Use plugin",
      pluginConfig.detail,
      pluginConfig.enabled ? "pass" : "fail"
    ),
  ];
  const ready = checks.every((item) => item.state === "pass" || item.state === "warn") &&
    selectedApp !== null &&
    wrapperExecutable &&
    mcp.registered &&
    runtimeMarketplace.ok &&
    pluginConfig.enabled;

  return {
    ready,
    summary: ready
      ? "Computer Use should be ready after a Codex restart if permissions are granted."
      : "Computer Use setup needs attention.",
    configPath,
    wrapperPath,
    apps,
    selectedApp,
    plugin,
    pluginCache,
    runtimeMarketplace,
    pluginConfig,
    marketplace,
    mcp,
    checks,
  };
}

function repairSetup(api) {
  const fs = require("node:fs");
  const messages = [];
  let status = getSetupStatus();
  let selectedApp = status.selectedApp;

  if (!selectedApp) {
    status = acquireComputerUseBundle(status, messages, api);
    selectedApp = status.selectedApp;
  }

  if (!selectedApp) {
    messages.push("OpenAI Computer Use is still missing after the official Codex update/install check.");
    messages.push("Finish any Codex installer that opened, or update Codex Desktop, then run Repair again.");
    messages.push("This tweak will not fetch OpenAI's signed helper from unofficial sources.");
    return {
      ok: false,
      messages,
      status,
    };
  }

  const wrapperPath = status.wrapperPath;
  if (fs.existsSync(wrapperPath) && !isExecutable(fs, wrapperPath)) {
    fs.chmodSync(wrapperPath, 0o755);
    messages.push(`Made launcher executable: ${wrapperPath}`);
  }

  try {
    ensurePluginCache(selectedApp, messages);
    ensureRuntimeMarketplace(selectedApp, messages);
  } catch (error) {
    const message = `Unable to prepare Computer Use plugin files: ${error?.message || error}`;
    messages.push(message);
    api.log.warn(message);
    return { ok: false, messages, status: getSetupStatus() };
  }

  if (!ensureMarketplaceRegistration({
    api,
    codexBin: selectedApp.codexBin,
    configPath: status.configPath,
    marketplaceRoot: selectedApp.marketplaceRoot,
    messages,
    backupConfig: true,
  })) {
    return { ok: false, messages, status: getSetupStatus() };
  }

  ensurePluginEnabled(status.configPath, messages);
  messages.push("Repair complete. Fully quit and reopen Codex Desktop before testing Computer Use.");
  return { ok: true, messages, status: getSetupStatus() };
}

function acquireComputerUseBundle(status, messages, api) {
  messages.push("OpenAI Computer Use was not found inside Codex.app or Codex (Beta).app.");
  messages.push("Trying Codex's official update/install flow, then re-checking the bundled helper.");

  const codexBin = findRepairCodexBin(status);
  if (!codexBin) {
    messages.push("Codex CLI was not found. Install or update Codex Desktop, then run Repair again.");
    return getSetupStatus();
  }

  messages.push(`Using Codex CLI: ${codexBin}`);

  const updateResult = runCodexCommand(codexBin, ["update"], 120000);
  appendCommandResult(
    messages,
    updateResult,
    "Codex update completed.",
    "Codex update did not complete."
  );
  if (!updateResult.ok) {
    api.log.warn("Codex update failed while repairing Computer Use:", updateResult.output);
  }

  let next = getSetupStatus();
  if (next.selectedApp) {
    messages.push("Computer Use bundle found after Codex update.");
    return next;
  }

  messages.push("Computer Use is still missing after update. Opening Codex's official app installer.");
  const appResult = runCodexCommand(codexBin, ["app"], 120000);
  appendCommandResult(
    messages,
    appResult,
    "Codex app installer command completed.",
    "Codex app installer command did not complete."
  );
  if (!appResult.ok) {
    api.log.warn("Codex app install flow failed while repairing Computer Use:", appResult.output);
  }

  next = getSetupStatus();
  if (next.selectedApp) {
    messages.push("Computer Use bundle found after Codex app install.");
  }
  return next;
}

async function getNativeSettings() {
  const [approvals, sound] = await Promise.all([
    readApprovals(),
    Promise.resolve(readSoundMode()),
  ]);
  return { approvals, sound, soundModes: SOUND_MODES };
}

async function readApprovals() {
  const fs = require("node:fs");
  const filePath = approvalsFilePath();
  if (!fs.existsSync(filePath)) {
    return {
      hasApprovalStore: false,
      filePath,
      approvedBundleIdentifiers: [],
      approvedApps: [],
    };
  }

  const approvedBundleIdentifiers = normalizeBundleIdentifiers(
    readApprovalsFile(fs, filePath).approvedBundleIdentifiers
  );
  return {
    hasApprovalStore: true,
    filePath,
    approvedBundleIdentifiers,
    approvedApps: await Promise.all(approvedBundleIdentifiers.map((id) => resolveApprovedApp(id))),
  };
}

async function removeApprovedApp(bundleIdentifier) {
  if (!bundleIdentifier || typeof bundleIdentifier !== "string") {
    throw new Error("bundleIdentifier is required");
  }

  const fs = require("node:fs");
  const path = require("node:path");
  const filePath = approvalsFilePath();
  if (!fs.existsSync(filePath)) return readApprovals();

  const next = normalizeBundleIdentifiers(
    readApprovalsFile(fs, filePath).approvedBundleIdentifiers
  ).filter((id) => id !== bundleIdentifier);
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(
    filePath,
    `${JSON.stringify({ approvedBundleIdentifiers: next }, null, 2)}\n`,
    "utf8"
  );
  return readApprovals();
}

function readSoundMode() {
  const { spawnSync } = require("node:child_process");
  if (process.platform !== "darwin") {
    return { value: null, effectiveValue: "foregroundClicks" };
  }

  const result = spawnSync(
    "/usr/bin/defaults",
    ["read", SOUND_DEFAULTS_DOMAIN, SOUND_DEFAULTS_KEY],
    { encoding: "utf8", timeout: 5000 }
  );
  const value = result.status === 0 ? result.stdout.trim() || null : null;
  return {
    value,
    effectiveValue: normalizeSoundMode(value),
  };
}

function writeSoundMode(value) {
  const { spawnSync } = require("node:child_process");
  const next = normalizeSoundMode(value);
  if (process.platform === "darwin") {
    const result = spawnSync(
      "/usr/bin/defaults",
      ["write", SOUND_DEFAULTS_DOMAIN, SOUND_DEFAULTS_KEY, next],
      { encoding: "utf8", timeout: 5000 }
    );
    if (result.status !== 0) {
      throw new Error((result.stderr || result.stdout || "Unable to save sound mode").trim());
    }
  }
  return readSoundMode();
}

async function openPermissionSettings(pane) {
  const { shell } = require("electron");
  const urls = {
    accessibility: "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility",
    screenRecording: "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture",
  };
  const url = urls[pane] || urls.screenRecording;
  await shell.openExternal(url);
  return { ok: true, pane };
}

function approvalsFilePath() {
  const path = require("node:path");
  return path.join(process.env.HOME, ...APPROVALS_REL);
}

function readApprovalsFile(fs, filePath) {
  try {
    const parsed = JSON.parse(fs.readFileSync(filePath, "utf8"));
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

function normalizeBundleIdentifiers(value) {
  const seen = new Set();
  const result = [];
  for (const item of Array.isArray(value) ? value : []) {
    const id = typeof item === "string" ? item.trim() : "";
    if (id && !seen.has(id)) {
      seen.add(id);
      result.push(id);
    }
  }
  return result;
}

async function resolveApprovedApp(bundleIdentifier) {
  const appPath = findAppPathByBundleIdentifier(bundleIdentifier);
  return {
    bundleIdentifier,
    displayName: appPath ? readAppDisplayName(appPath) : bundleIdentifier,
    iconDataURL: appPath ? await readAppIconDataUrl(appPath) : null,
    appPath,
  };
}

function findAppPathByBundleIdentifier(bundleIdentifier) {
  const { spawnSync } = require("node:child_process");
  const escaped = bundleIdentifier.replace(/["\\]/g, "\\$&");
  const result = spawnSync(
    "/usr/bin/mdfind",
    [`kMDItemCFBundleIdentifier == "${escaped}"`],
    { encoding: "utf8", timeout: 5000 }
  );
  if (result.status !== 0) return null;
  return (result.stdout || "")
    .split("\n")
    .map((line) => line.trim())
    .find((line) => line.endsWith(".app")) || null;
}

function readAppDisplayName(appPath) {
  const path = require("node:path");
  const { spawnSync } = require("node:child_process");
  const plist = path.join(appPath, "Contents", "Info.plist");
  for (const key of ["CFBundleDisplayName", "CFBundleName"]) {
    const result = spawnSync(
      "/usr/libexec/PlistBuddy",
      ["-c", `Print :${key}`, plist],
      { encoding: "utf8", timeout: 5000 }
    );
    const value = result.status === 0 ? result.stdout.trim() : "";
    if (value) return value;
  }
  return path.basename(appPath, ".app");
}

async function readAppIconDataUrl(appPath) {
  try {
    const { app } = require("electron");
    if (!app?.isReady?.()) return null;
    const icon = await app.getFileIcon(appPath, { size: "normal" });
    return icon?.isEmpty?.() ? null : icon.toDataURL();
  } catch {
    return null;
  }
}

function normalizeSoundMode(value) {
  return SOUND_MODES.some((mode) => mode.value === value)
    ? value
    : "foregroundClicks";
}

function inspectApp(app) {
  const fs = require("node:fs");
  const path = require("node:path");
  const marketplaceRoot = path.join(app, MARKETPLACE_REL);
  const pluginRoot = path.join(app, PLUGIN_REL);
  const clientPath = path.join(app, CLIENT_REL);
  const pluginJsonPath = path.join(app, PLUGIN_JSON_REL);
  const marketplaceJsonPath = path.join(app, MARKETPLACE_JSON_REL);
  const codexBin = path.join(app, "Contents/Resources/codex");
  const marketplaceAdvertisesComputerUse = safeReadFile(fs, marketplaceJsonPath).includes('"name": "computer-use"');
  const plugin = readPluginMetadata(fs, pluginJsonPath, pluginRoot);

  return {
    app,
    codexBin,
    marketplaceRoot,
    pluginRoot,
    clientPath,
    marketplaceJsonPath,
    pluginJsonPath,
    appExists: fs.existsSync(app),
    codexBinExecutable: isExecutable(fs, codexBin),
    marketplaceRootExists: fs.existsSync(marketplaceRoot),
    pluginRootExists: fs.existsSync(pluginRoot),
    pluginJsonExists: fs.existsSync(pluginJsonPath),
    clientExecutable: isExecutable(fs, clientPath),
    marketplaceAdvertisesComputerUse,
    plugin,
    usable: isExecutable(fs, codexBin) &&
      isExecutable(fs, clientPath) &&
      fs.existsSync(pluginJsonPath) &&
      marketplaceAdvertisesComputerUse,
  };
}

function appCandidates() {
  const path = require("node:path");
  const candidates = [];
  if (process.resourcesPath) {
    candidates.push(path.dirname(path.dirname(process.resourcesPath)));
  }
  candidates.push(...APP_CANDIDATES);
  return [...new Set(candidates.filter(Boolean))];
}

function inspectMarketplace(configText, selectedApp) {
  if (!selectedApp) {
    return {
      ok: false,
      fixable: false,
      detail: "Cannot check marketplace until a bundled Computer Use app is found.",
    };
  }

  const section = readTomlSection(configText, "marketplaces.openai-bundled");
  if (!section) {
    return {
      ok: false,
      fixable: true,
      detail: "openai-bundled marketplace is not registered. Repair can add it.",
    };
  }

  const source = readTomlString(section, "source");
  if (source === selectedApp.marketplaceRoot) {
    return {
      ok: true,
      fixable: false,
      source,
      detail: `Registered from ${source}`,
    };
  }

  return {
    ok: false,
    fixable: true,
    source,
    detail: source
      ? `Registered from ${source}. Repair can point it at ${selectedApp.marketplaceRoot}.`
      : "openai-bundled marketplace source is missing. Repair can re-register it.",
  };
}

function inspectMcp(configText, wrapperPath) {
  const section = readTomlSection(configText, "mcp_servers.computer-use");
  const command = section ? readTomlString(section, "command") : null;
  return {
    registered: Boolean(section),
    command,
    pointsAtThisTweak: command === wrapperPath,
  };
}

function inspectRuntimeMarketplace(fs, selectedApp) {
  if (!selectedApp) {
    return {
      ok: false,
      detail: "Cannot check runtime marketplace until a bundled Computer Use app is found.",
    };
  }

  const path = require("node:path");
  const root = runtimeMarketplaceRoot();
  const marketplacePath = path.join(root, ".agents/plugins/marketplace.json");
  const pluginRoot = path.join(root, "plugins/computer-use");
  const clientPath = path.join(
    pluginRoot,
    "Codex Computer Use.app/Contents/SharedSupport/SkyComputerUseClient.app/Contents/MacOS/SkyComputerUseClient"
  );
  const marketplace = readJsonFile(fs, marketplacePath) || {};
  const advertisesComputerUse = Array.isArray(marketplace.plugins) &&
    marketplace.plugins.some((plugin) => plugin?.name === "computer-use");
  const ok = advertisesComputerUse &&
    fs.existsSync(path.join(pluginRoot, ".codex-plugin/plugin.json")) &&
    isExecutable(fs, clientPath);

  return {
    ok,
    path: root,
    detail: ok
      ? `Includes computer-use at ${root}`
      : `Missing computer-use in ${root}. Startup repair will restore it after Codex rewrites bundled plugins.`,
  };
}

function inspectPluginConfig(configText) {
  const section = readTomlSection(configText, PLUGIN_CONFIG_SECTION);
  if (!section) {
    return {
      enabled: false,
      detail: `[${PLUGIN_CONFIG_SECTION}] is missing. Repair can enable it.`,
    };
  }

  const enabled = readTomlBoolean(section, "enabled") === true;
  return {
    enabled,
    detail: enabled
      ? "computer-use@openai-bundled is enabled."
      : "computer-use@openai-bundled is disabled. Repair can enable it.",
  };
}

function ensureRuntimeMarketplace(selectedApp, messages) {
  const fs = require("node:fs");
  const path = require("node:path");
  const current = inspectRuntimeMarketplace(fs, selectedApp);
  if (current.ok) {
    messages.push(`Runtime bundled marketplace includes computer-use: ${current.path}`);
    return;
  }

  const sourceMarketplace = readJsonFile(fs, selectedApp.marketplaceJsonPath);
  const computerUseEntry = sourceMarketplace?.plugins?.find((plugin) => plugin?.name === "computer-use");
  if (!computerUseEntry) {
    throw new Error(`Computer Use is missing from ${selectedApp.marketplaceJsonPath}`);
  }

  const root = runtimeMarketplaceRoot();
  const marketplacePath = path.join(root, ".agents/plugins/marketplace.json");
  const pluginRoot = path.join(root, "plugins/computer-use");
  fs.mkdirSync(path.dirname(marketplacePath), { recursive: true });
  fs.mkdirSync(path.dirname(pluginRoot), { recursive: true });

  const copyResult = runCommand("/usr/bin/ditto", [selectedApp.pluginRoot, pluginRoot], 60000);
  if (!copyResult.ok) {
    throw new Error(copyResult.output || `Unable to copy Computer Use into ${pluginRoot}`);
  }

  const nextMarketplace = normalizeRuntimeMarketplace(
    readJsonFile(fs, marketplacePath),
    sourceMarketplace,
    computerUseEntry
  );
  fs.writeFileSync(marketplacePath, `${JSON.stringify(nextMarketplace, null, 2)}\n`, "utf8");

  const verified = inspectRuntimeMarketplace(fs, selectedApp);
  if (!verified.ok) {
    throw new Error(`runtime marketplace did not verify at ${root}`);
  }
  messages.push(`Restored computer-use in Codex runtime marketplace: ${root}`);
}

function normalizeRuntimeMarketplace(current, sourceMarketplace, computerUseEntry) {
  const base = current && typeof current === "object"
    ? current
    : {
        name: MARKETPLACE_NAME,
        interface: sourceMarketplace.interface || { displayName: "OpenAI Bundled" },
        plugins: [],
      };
  const plugins = Array.isArray(base.plugins) ? base.plugins : [];
  const withoutComputerUse = plugins.filter((plugin) => plugin?.name !== "computer-use");
  return {
    ...base,
    name: MARKETPLACE_NAME,
    interface: base.interface || sourceMarketplace.interface || { displayName: "OpenAI Bundled" },
    plugins: [...withoutComputerUse, computerUseEntry],
  };
}

function runtimeMarketplaceRoot() {
  const path = require("node:path");
  return path.join(
    process.env.CODEX_HOME || path.join(process.env.HOME, ".codex"),
    ".tmp",
    "bundled-marketplaces",
    MARKETPLACE_NAME
  );
}

function ensureMarketplaceRegistration({ api, codexBin, configPath, marketplaceRoot, messages, backupConfig }) {
  const fs = require("node:fs");
  const addResult = runCodexMarketplace(codexBin, ["add", marketplaceRoot]);
  messages.push(addResult.output.trim() || `Checked ${MARKETPLACE_NAME} marketplace registration.`);

  if (!addResult.ok && addResult.output.includes("already added from a different source")) {
    if (backupConfig && fs.existsSync(configPath)) {
      const backup = `${configPath}.backup-computer-use-${timestamp()}`;
      fs.copyFileSync(configPath, backup);
      messages.push(`Backed up Codex config: ${backup}`);
    }

    const removeResult = runCodexMarketplace(codexBin, ["remove", MARKETPLACE_NAME]);
    messages.push(removeResult.output.trim() || `Removed stale ${MARKETPLACE_NAME} marketplace.`);
    if (!removeResult.ok) {
      api.log.warn("Failed to remove stale marketplace:", removeResult.output);
      return false;
    }

    const retryResult = runCodexMarketplace(codexBin, ["add", marketplaceRoot]);
    messages.push(retryResult.output.trim() || `Registered ${MARKETPLACE_NAME} marketplace.`);
    if (!retryResult.ok) {
      api.log.warn("Failed to register marketplace:", retryResult.output);
      return false;
    }
    return true;
  }

  if (!addResult.ok) {
    api.log.warn("Marketplace repair failed:", addResult.output);
    return false;
  }

  return true;
}

function ensurePluginEnabled(configPath, messages) {
  const fs = require("node:fs");
  const path = require("node:path");
  const current = safeReadFile(fs, configPath);
  if (inspectPluginConfig(current).enabled) {
    messages.push("Native Computer Use plugin is enabled.");
    return;
  }

  fs.mkdirSync(path.dirname(configPath), { recursive: true });
  fs.writeFileSync(
    configPath,
    upsertTomlBoolean(current, PLUGIN_CONFIG_SECTION, "enabled", true),
    "utf8"
  );
  messages.push("Enabled native Computer Use plugin: computer-use@openai-bundled");
}

function inspectPluginCache(fs, plugin) {
  const path = require("node:path");
  const version = plugin?.version || null;
  if (!version) {
    return {
      ok: false,
      path: null,
      version,
      detail: "Cannot check cache until Computer Use plugin metadata is available.",
    };
  }

  const root = pluginCacheRoot(version);
  const pluginJsonPath = path.join(root, ".codex-plugin/plugin.json");
  const clientPath = path.join(
    root,
    "Codex Computer Use.app/Contents/SharedSupport/SkyComputerUseClient.app/Contents/MacOS/SkyComputerUseClient"
  );
  const ok = fs.existsSync(pluginJsonPath) && isExecutable(fs, clientPath);
  return {
    ok,
    path: root,
    version,
    detail: ok
      ? `Installed at ${root}`
      : `Missing at ${root}. Repair can install it from the official Codex bundle.`,
  };
}

function ensurePluginCache(selectedApp, messages) {
  const fs = require("node:fs");
  const path = require("node:path");
  const cache = inspectPluginCache(fs, selectedApp.plugin);
  if (cache.ok) {
    messages.push(`Computer Use plugin cache is installed: ${cache.path}`);
    return;
  }

  if (!selectedApp.plugin?.version) {
    throw new Error("Computer Use plugin version is unavailable.");
  }

  fs.mkdirSync(path.dirname(cache.path), { recursive: true });
  const result = runCommand("/usr/bin/ditto", [selectedApp.pluginRoot, cache.path], 60000);
  if (!result.ok) {
    throw new Error(result.output || "ditto failed");
  }

  const verified = inspectPluginCache(fs, selectedApp.plugin);
  if (!verified.ok) {
    throw new Error(`cache copy did not verify at ${verified.path}`);
  }
  messages.push(`Installed Computer Use plugin cache: ${verified.path}`);
}

function pluginCacheRoot(version) {
  const path = require("node:path");
  return path.join(
    process.env.CODEX_HOME || path.join(process.env.HOME, ".codex"),
    "plugins",
    "cache",
    MARKETPLACE_NAME,
    "computer-use",
    version
  );
}

function readPluginMetadata(fs, pluginJsonPath, pluginRoot) {
  const path = require("node:path");
  const raw = safeReadFile(fs, pluginJsonPath);
  if (!raw) return null;

  try {
    const plugin = JSON.parse(raw);
    const ui = plugin.interface || {};
    const logoPath = typeof ui.logo === "string"
      ? path.resolve(pluginRoot, ui.logo)
      : path.join(pluginRoot, "assets/app-icon.png");
    return {
      name: ui.displayName || plugin.name || "Computer Use",
      version: plugin.version || null,
      description: plugin.description || "Control desktop apps on macOS from Codex through Computer Use.",
      shortDescription: ui.shortDescription || "Control Mac apps from Codex",
      longDescription: ui.longDescription || fallbackPluginMetadata().longDescription,
      developerName: ui.developerName || plugin.author?.name || "OpenAI",
      category: ui.category || "Productivity",
      websiteURL: ui.websiteURL || plugin.homepage || "https://openai.com/",
      privacyPolicyURL: ui.privacyPolicyURL || null,
      termsOfServiceURL: ui.termsOfServiceURL || null,
      defaultPrompt: Array.isArray(ui.defaultPrompt) ? ui.defaultPrompt : [],
      brandColor: ui.brandColor || "#0F172A",
      iconDataUrl: readIconDataUrl(fs, logoPath),
    };
  } catch {
    return null;
  }
}

function readIconDataUrl(fs, file) {
  try {
    const data = fs.readFileSync(file);
    return `data:image/png;base64,${data.toString("base64")}`;
  } catch {
    return null;
  }
}

function readJsonFile(fs, file) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return null;
  }
}

function fallbackPluginMetadata() {
  return {
    name: "Computer Use",
    version: null,
    description: "Control desktop apps on macOS from Codex through Computer Use.",
    shortDescription: "Control Mac apps from Codex",
    longDescription:
      "Mac Computer Use lets Codex use any app on your computer, including your web browsers and files you allow it to access. It may take screenshots or page content while working. You stay in control: you choose which apps to allow Codex to access, you can stop actions at any time, and control whether we use screenshots for training.",
    developerName: "OpenAI",
    category: "Productivity",
    websiteURL: "https://openai.com/",
    privacyPolicyURL: "https://openai.com/policies/row-privacy-policy/",
    termsOfServiceURL: "https://openai.com/policies/row-terms-of-use/",
    defaultPrompt: [
      "Play a playlist to help me lock in",
      "Build & run my open Xcode project and test it for bugs",
      "Play a game in Chess.app",
    ],
    brandColor: "#0F172A",
    iconDataUrl: null,
  };
}

function check(ok, label, detail, overrideState) {
  return {
    label,
    detail,
    state: overrideState || (ok ? "pass" : "fail"),
  };
}

function readTomlSection(toml, name) {
  if (!toml) return null;
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const header = new RegExp(`^\\s*\\[${escaped}\\]\\s*$`, "m");
  const match = header.exec(toml);
  if (!match) return null;

  const rest = toml.slice(match.index + match[0].length);
  const next = rest.search(/^\s*\[/m);
  return next === -1 ? rest : rest.slice(0, next);
}

function readTomlString(section, key) {
  const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = section.match(new RegExp(`^\\s*${escaped}\\s*=\\s*(".*?"|'.*?'|[^\\n#]+)`, "m"));
  if (!match) return null;
  const raw = match[1].trim();
  if (raw.startsWith('"')) {
    try {
      return JSON.parse(raw);
    } catch {
      return raw.slice(1, -1);
    }
  }
  if (raw.startsWith("'")) return raw.slice(1, -1);
  return raw.trim();
}

function readTomlBoolean(section, key) {
  const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = section.match(new RegExp(`^\\s*${escaped}\\s*=\\s*(true|false)\\s*(?:#.*)?$`, "m"));
  if (!match) return null;
  return match[1] === "true";
}

function upsertTomlBoolean(toml, sectionName, key, value) {
  const boolText = value ? "true" : "false";
  const escapedSection = sectionName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const header = new RegExp(`^\\s*\\[${escapedSection}\\]\\s*$`, "m");
  const match = header.exec(toml || "");
  if (!match) {
    const prefix = toml && !toml.endsWith("\n") ? `${toml}\n` : (toml || "");
    const spacer = prefix && !prefix.endsWith("\n\n") ? "\n" : "";
    return `${prefix}${spacer}[${sectionName}]\n${key} = ${boolText}\n`;
  }

  const sectionStart = match.index + match[0].length;
  const rest = toml.slice(sectionStart);
  const nextSection = rest.search(/^\s*\[/m);
  const sectionEnd = nextSection === -1 ? toml.length : sectionStart + nextSection;
  const sectionText = toml.slice(sectionStart, sectionEnd);
  const escapedKey = key.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const keyLine = new RegExp(`(^\\s*${escapedKey}\\s*=\\s*)(true|false)(\\s*(?:#.*)?$)`, "m");
  const nextSectionText = keyLine.test(sectionText)
    ? sectionText.replace(keyLine, `$1${boolText}$3`)
    : `${sectionText.replace(/\s*$/, "")}\n${key} = ${boolText}\n`;
  return `${toml.slice(0, sectionStart)}${nextSectionText}${toml.slice(sectionEnd)}`;
}

function safeReadFile(fs, file) {
  try {
    return fs.readFileSync(file, "utf8");
  } catch {
    return "";
  }
}

function isExecutable(fs, file) {
  try {
    fs.accessSync(file, fs.constants.X_OK);
    return true;
  } catch {
    return false;
  }
}

function findRepairCodexBin(status) {
  const appWithCli = (status.apps || []).find((app) => app.codexBinExecutable);
  if (appWithCli) return appWithCli.codexBin;
  return findCommand("codex");
}

function findCommand(command) {
  const { spawnSync } = require("node:child_process");
  const result = spawnSync(
    "/bin/sh",
    ["-lc", `command -v ${command}`],
    { encoding: "utf8", timeout: 5000 }
  );
  if (result.status !== 0) return null;
  return (result.stdout || "").split("\n").map((line) => line.trim()).find(Boolean) || null;
}

function runCommand(command, args, timeout) {
  const { spawnSync } = require("node:child_process");
  const result = spawnSync(
    command,
    args,
    { encoding: "utf8", timeout }
  );
  const output = [
    result.stdout || "",
    result.stderr || "",
    result.error?.message || "",
  ].filter(Boolean).join("\n").trim();
  return {
    ok: result.status === 0,
    output,
  };
}

function runCodexCommand(codexBin, args, timeout) {
  return runCommand(codexBin, args, timeout);
}

function appendCommandResult(messages, result, okText, failText) {
  const lines = result.output
    ? result.output.split(/\r?\n/).map((line) => line.trim()).filter(Boolean)
    : [];
  if (lines.length > 0) {
    messages.push(...lines.slice(-8));
    return;
  }
  messages.push(result.ok ? okText : failText);
}

function runCodexMarketplace(codexBin, args) {
  return runCodexCommand(codexBin, ["plugin", "marketplace", ...args], 15000);
}

function timestamp() {
  return new Date()
    .toISOString()
    .replace(/[-:]/g, "")
    .replace(/\..*$/, "")
    .replace("T", "");
}

function renderSetupPage(root, api) {
  root.innerHTML = "";
  const el = createEl;
  const state = {
    loading: false,
    status: null,
    nativeSettings: null,
    messages: [],
    soundMenuOpen: false,
    troubleshootDetailsOpen: false,
    removeTarget: null,
  };

  const wrap = el("div", {
    style: `
      display: grid;
      gap: 22px;
      max-width: 760px;
      padding: 4px 0 32px;
      color: var(--token-text-primary, var(--text-primary, inherit));
    `,
  });
  const pluginGroup = el("section", { style: "display: grid; gap: 8px;" });
  const allowedAppsGroup = el("section", { style: "display: grid; gap: 8px;" });
  const soundsGroup = el("section", { style: "display: grid; gap: 8px;" });
  const advancedGroup = el("section", { style: "display: grid; gap: 8px;" });
  const dialogLayer = el("div");
  const details = el("pre", {
    style: `
      display: none;
      overflow: auto;
      max-height: 260px;
      margin: 0;
      padding: 12px;
      border-radius: 10px;
      background: rgba(127, 127, 127, 0.12);
      font-size: 12px;
      white-space: pre-wrap;
    `,
  });
  const messages = el("div", { style: "display: grid; gap: 6px;" });
  const refreshButton = button("Refresh", "secondary");
  const installButton = button("Install", "primary");
  const repairButton = button("Repair", "secondary");
  const detailsButton = button("Details", "secondary");
  const accessibilityButton = button("Accessibility", "secondary");
  const screenRecordingButton = button("Screen Recording", "secondary");

  refreshButton.addEventListener("click", () => refresh());
  installButton.addEventListener("click", () => repair());
  repairButton.addEventListener("click", () => repair());
  accessibilityButton.addEventListener("click", () => {
    api.ipc.invoke("open-permission-settings", { pane: "accessibility" });
  });
  screenRecordingButton.addEventListener("click", () => {
    api.ipc.invoke("open-permission-settings", { pane: "screenRecording" });
  });
  detailsButton.addEventListener("click", () => {
    state.troubleshootDetailsOpen = !state.troubleshootDetailsOpen;
    render();
  });

  wrap.append(pluginGroup, allowedAppsGroup, soundsGroup, advancedGroup, messages, details, dialogLayer);
  root.appendChild(wrap);

  refresh();

  async function refresh() {
    state.loading = true;
    state.messages = [];
    render();
    try {
      const [status, nativeSettings] = await Promise.all([
        api.ipc.invoke("setup-status"),
        api.ipc.invoke("native-settings"),
      ]);
      state.status = status;
      state.nativeSettings = nativeSettings;
    } catch (error) {
      state.status = null;
      state.nativeSettings = null;
      state.messages = [`Failed to load setup status: ${error?.message || error}`];
    } finally {
      state.loading = false;
      render();
    }
  }

  async function repair() {
    state.loading = true;
    state.messages = ["Running setup repair..."];
    render();
    try {
      const result = await api.ipc.invoke("repair-setup");
      state.status = result.status;
      state.nativeSettings = await api.ipc.invoke("native-settings");
      state.messages = result.messages || [];
      if (!result.ok) {
        state.messages.push("Repair did not complete. See details below.");
      }
    } catch (error) {
      state.messages = [`Repair failed: ${error?.message || error}`];
    } finally {
      state.loading = false;
      render();
    }
  }

  async function removeApprovedApp(app) {
    state.loading = true;
    state.removeTarget = null;
    state.messages = [];
    render();
    try {
      const approvals = await api.ipc.invoke("remove-approved-app", {
        bundleIdentifier: app.bundleIdentifier,
      });
      state.nativeSettings = {
        ...(state.nativeSettings || {}),
        approvals,
      };
      state.messages = ["Allowed app removed"];
    } catch (error) {
      state.messages = [`Unable to save allowed apps: ${error?.message || error}`];
    } finally {
      state.loading = false;
      render();
    }
  }

  async function writeSound(value) {
    state.loading = true;
    state.soundMenuOpen = false;
    state.messages = [];
    render();
    try {
      const sound = await api.ipc.invoke("write-sound-mode", { value });
      state.nativeSettings = {
        ...(state.nativeSettings || {}),
        sound,
        soundModes: state.nativeSettings?.soundModes || SOUND_MODES,
      };
    } catch (error) {
      state.messages = [`Unable to save sound setting: ${error?.message || error}`];
    } finally {
      state.loading = false;
      render();
    }
  }

  function render() {
    refreshButton.disabled = state.loading;
    installButton.disabled = state.loading;
    repairButton.disabled = state.loading;
    accessibilityButton.disabled = state.loading;
    screenRecordingButton.disabled = state.loading;
    pluginGroup.innerHTML = "";
    allowedAppsGroup.innerHTML = "";
    soundsGroup.innerHTML = "";
    advancedGroup.innerHTML = "";
    messages.innerHTML = "";
    dialogLayer.innerHTML = "";
    const plugin = state.status?.plugin || fallbackPluginMetadata();
    installButton.textContent = state.loading ? "Checking..." : "Install";
    repairButton.textContent = state.loading ? "Working..." : "Repair";
    details.style.display = "none";
    detailsButton.textContent = state.troubleshootDetailsOpen ? "Hide details" : "Details";

    if (state.loading && !state.status) {
      pluginGroup.append(settingsGroup(
        "Plugin",
        settingsPanel([settingsRow({
          title: "Loading Computer Use",
          description: "Checking Codex app, MCP, and marketplace state.",
          control: statusPill("Loading", "info"),
        })])
      ));
    } else if (state.status) {
      pluginGroup.append(settingsGroup(
        "Plugin",
        pluginCard(plugin, state.status, state.status.ready ? statusPill("Installed", "pass") : installButton)
      ));
      allowedAppsGroup.append(settingsGroup(
        "Always-allowed apps",
        allowedAppsPanel(state.nativeSettings?.approvals, (app) => {
          state.removeTarget = app;
          render();
        }, state.loading)
      ));
      soundsGroup.append(soundModeDropdown(
        state.nativeSettings?.sound,
        state.nativeSettings?.soundModes || SOUND_MODES,
        state.soundMenuOpen,
        () => {
          state.soundMenuOpen = !state.soundMenuOpen;
          render();
        },
        (value) => writeSound(value),
        state.loading
      ));
      advancedGroup.append(settingsGroup(
        "Troubleshoot",
        troubleshootPanel(
          state.status,
          refreshButton,
          repairButton,
          detailsButton,
          accessibilityButton,
          screenRecordingButton,
          state.troubleshootDetailsOpen
        )
      ));
    } else {
      pluginGroup.append(settingsGroup(
        "Plugin",
        settingsPanel([settingsRow({
          title: "Computer Use plugin unavailable",
          description: "Click Refresh to check again.",
          control: refreshButton,
        })])
      ));
    }

    for (const message of state.messages) {
      messages.append(el("div", {
        text: message,
        style: `
          padding: 10px 12px;
          border-radius: 10px;
          background: rgba(127, 127, 127, 0.12);
          font-size: 13px;
        `,
      }));
    }

    details.textContent = state.status
      ? JSON.stringify({ status: state.status, nativeSettings: state.nativeSettings }, null, 2)
      : state.messages.join("\n");

    if (state.removeTarget) {
      dialogLayer.append(removeConfirmationDialog(
        state.removeTarget,
        () => {
          state.removeTarget = null;
          render();
        },
        () => removeApprovedApp(state.removeTarget)
      ));
    }
  }
}

function settingsGroup(title, body) {
  const section = createEl("section", {
    style: "display: grid; gap: 8px;",
  });
  section.append(
    createEl("h3", {
      text: title,
      style: `
        margin: 0;
        font-size: 13px;
        line-height: 1.3;
        font-weight: 650;
      `,
    }),
    body
  );
  return section;
}

function settingsPanel(children) {
  const panel = createEl("div", {
    style: `
      display: grid;
      gap: 0;
      border: 1px solid var(--token-border, rgba(127, 127, 127, 0.18));
      border-radius: 10px;
      background: var(--token-main-surface-primary, transparent);
      overflow: hidden;
    `,
  });
  for (const child of children) {
    panel.append(child);
  }
  const last = panel.lastElementChild;
  if (last) last.style.borderBottom = "0";
  return panel;
}

function settingsRow({ icon, title, description, control, centered = false }) {
  const row = createEl("div", {
    style: `
      display: grid;
      grid-template-columns: ${icon ? "40px " : ""}minmax(0, 1fr) auto;
      gap: 12px;
      align-items: center;
      min-height: 62px;
      padding: 11px 14px;
      border-bottom: 1px solid var(--token-border, rgba(127, 127, 127, 0.14));
    `,
  });
  if (icon) row.append(icon);
  const copy = createEl("div", {
    style: `
      display: grid;
      gap: 2px;
      min-width: 0;
      text-align: ${centered ? "center" : "left"};
    `,
  });
  copy.append(
    createEl("div", {
      text: title,
      style: `
        font-size: 14px;
        font-weight: ${centered ? "400" : "550"};
        color: ${centered ? "var(--token-text-secondary, var(--text-secondary, #666))" : "inherit"};
      `,
    })
  );
  if (description) {
    copy.append(createEl("div", {
      text: description,
      style: `
        color: var(--token-text-secondary, var(--text-secondary, #666));
        font-size: 12px;
        line-height: 1.35;
      `,
    }));
  }
  row.append(copy);
  row.append(control || createEl("span"));
  return row;
}

function allowedAppsPanel(approvals, onRequestRemoval, disabled) {
  if (!approvals) {
    return settingsPanel([settingsRow({
      title: "Loading allowed apps",
      description: null,
      control: statusPill("Loading", "info"),
    })]);
  }

  const apps = approvals.approvedApps || [];
  if (apps.length === 0) {
    return settingsPanel([settingsRow({
      title: "None yet",
      centered: true,
    })]);
  }

  return settingsPanel(apps.map((app) => settingsRow({
    icon: approvedAppIcon(app),
    title: app.displayName || app.bundleIdentifier,
    description: null,
    control: removeAppButton(app, onRequestRemoval, disabled),
  })));
}

function approvedAppIcon(app) {
  if (app.iconDataURL) {
    const icon = createEl("img", {
      style: `
        width: 36px;
        height: 36px;
        border-radius: 8px;
      `,
    });
    icon.src = app.iconDataURL;
    icon.alt = "";
    icon.draggable = false;
    return icon;
  }

  return createEl("div", {
    text: (app.displayName || app.bundleIdentifier || "?").slice(0, 1).toUpperCase(),
    style: `
      display: grid;
      place-items: center;
      width: 36px;
      height: 36px;
      border-radius: 8px;
      background: rgba(127, 127, 127, 0.12);
      color: var(--token-text-secondary, var(--text-secondary, #666));
      font-size: 14px;
      font-weight: 650;
    `,
  });
}

function removeAppButton(app, onRequestRemoval, disabled) {
  const node = createEl("button", {
    text: "x",
    style: `
      appearance: none;
      display: inline-grid;
      place-items: center;
      width: 28px;
      height: 28px;
      border: 0;
      border-radius: 999px;
      background: transparent;
      color: var(--token-text-secondary, var(--text-secondary, #666));
      cursor: ${disabled ? "default" : "pointer"};
      font: inherit;
      font-size: 16px;
      line-height: 1;
    `,
  });
  node.disabled = disabled;
  node.setAttribute("aria-label", `Remove ${app.displayName || app.bundleIdentifier}`);
  node.addEventListener("click", () => onRequestRemoval(app));
  return node;
}

function pluginCard(plugin, status, control) {
  const card = createEl("div", {
    style: `
      display: grid;
      gap: 0;
      border: 1px solid var(--token-border, rgba(127, 127, 127, 0.18));
      border-radius: 10px;
      background: var(--token-main-surface-primary, transparent);
      overflow: hidden;
    `,
  });
  const summary = settingsRow({
    icon: pluginIcon(plugin),
    title: `${plugin.name || "Computer Use"}${plugin.version ? ` v${plugin.version}` : ""}`,
    description: pluginDescription(plugin),
    control,
  });
  card.append(summary);
  if (!status.ready) {
    const detail = createEl("div", {
      style: `
        display: grid;
        gap: 12px;
        padding: 0 14px 14px 66px;
        border-bottom: 1px solid var(--token-border, rgba(127, 127, 127, 0.14));
      `,
    });
    detail.append(statusNote("warn", status.summary));
    card.append(detail);
  }
  const last = card.lastElementChild;
  if (last) last.style.borderBottom = "0";
  return card;
}

function pluginDescription(plugin) {
  return [
    plugin.shortDescription || plugin.description,
    plugin.developerName ? `by ${plugin.developerName}` : null,
  ].filter(Boolean).join(" - ");
}

function pluginIcon(plugin) {
  if (plugin.iconDataUrl) {
    const icon = createEl("img", {
      style: `
        width: 40px;
        height: 40px;
        border-radius: 9px;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      `,
    });
    icon.src = plugin.iconDataUrl;
    icon.alt = "";
    icon.draggable = false;
    return icon;
  }
  return createEl("div", {
    text: "C",
    style: `
      display: grid;
      place-items: center;
      width: 40px;
      height: 40px;
      border-radius: 9px;
      background: ${plugin.brandColor || "#0F172A"};
      color: white;
      font-size: 18px;
      font-weight: 650;
    `,
  });
}

function soundModeDropdown(sound, modes, open, onToggle, onSelect, disabled) {
  const value = normalizeSoundMode(sound?.value || sound?.effectiveValue);
  const current = modes.find((mode) => mode.value === value) || modes[0];
  const root = createEl("div", {
    style: "position: relative; width: max-content; max-width: 100%;",
  });
  const trigger = createEl("button", {
    style: `
      appearance: none;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      border: 1px solid var(--token-border, rgba(127, 127, 127, 0.28));
      border-radius: 8px;
      background: var(--token-main-surface-secondary, rgba(127, 127, 127, 0.08));
      color: inherit;
      cursor: ${disabled ? "default" : "pointer"};
      font: inherit;
      font-size: 13px;
      padding: 7px 10px;
      max-width: 100%;
      white-space: nowrap;
    `,
  });
  trigger.append(
    createEl("span", { text: current.label }),
    chevronDownIcon()
  );
  trigger.setAttribute("aria-haspopup", "menu");
  trigger.setAttribute("aria-expanded", open ? "true" : "false");
  trigger.disabled = disabled;
  trigger.addEventListener("click", onToggle);
  root.append(trigger);

  if (open && !disabled) {
    const menu = createEl("div", {
      style: `
        position: absolute;
        z-index: 20;
        top: calc(100% + 6px);
        left: 0;
        display: grid;
        min-width: 290px;
        padding: 4px;
        border: 1px solid var(--token-border, rgba(127, 127, 127, 0.18));
        border-radius: 10px;
        background: var(--token-main-surface-primary, #fff);
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.16);
      `,
    });
    for (const mode of modes) {
      const item = createEl("button", {
        style: `
          appearance: none;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          border: 0;
          border-radius: 7px;
          background: ${mode.value === value ? "rgba(127, 127, 127, 0.12)" : "transparent"};
          color: inherit;
          cursor: pointer;
          font: inherit;
          font-size: 13px;
          padding: 8px 10px;
          text-align: left;
        `,
      });
      item.append(
        createEl("span", { text: mode.label }),
        mode.value === value ? checkIcon() : createEl("span", { style: "width: 14px;" })
      );
      item.addEventListener("click", () => onSelect(mode.value));
      menu.append(item);
    }
    root.append(menu);
  }

  return root;
}

function chevronDownIcon() {
  return svgIcon("m6 8 4 4 4-4", "width: 14px; height: 14px; opacity: 0.72;");
}

function checkIcon() {
  return svgIcon("m5 10 3 3 7-7", "width: 14px; height: 14px; opacity: 0.78;");
}

function svgIcon(pathD, style) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", "0 0 20 20");
  svg.setAttribute("fill", "none");
  svg.setAttribute("aria-hidden", "true");
  svg.setAttribute("style", `display: block; flex: 0 0 auto; ${style || ""}`);
  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.setAttribute("d", pathD);
  path.setAttribute("stroke", "currentColor");
  path.setAttribute("stroke-width", "1.8");
  path.setAttribute("stroke-linecap", "round");
  path.setAttribute("stroke-linejoin", "round");
  svg.append(path);
  return svg;
}

function troubleshootPanel(
  status,
  refreshButton,
  repairButton,
  detailsButton,
  accessibilityButton,
  screenRecordingButton,
  detailsOpen
) {
  const rows = [];
  rows.push(settingsRow({
    title: "Status",
    description: status.summary,
    control: statusPill(status.ready ? "Ready" : "Needs setup", status.ready ? "pass" : "warn"),
  }));
  const permissionActions = createEl("div", {
    style: "display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 6px;",
  });
  permissionActions.append(accessibilityButton, screenRecordingButton);
  rows.push(settingsRow({
    title: "Permissions",
    description: "Open the macOS panes used by Computer Use. If access still fails, add Codex.app too.",
    control: permissionActions,
  }));
  const actions = createEl("div", {
    style: "display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 6px;",
  });
  actions.append(refreshButton, repairButton, detailsButton);
  rows.push(settingsRow({
    title: "Diagnostics",
    description: "Check the bundled helper and repair the Codex++ MCP registration.",
    control: actions,
  }));

  if (detailsOpen) {
    rows.push(...(status.checks || []).map((item) => settingsRow({
      icon: setupDot(item.state),
      title: item.label,
      description: item.detail,
      control: statusPill(item.state === "pass" ? "Ready" : item.state === "warn" ? "Check" : "Fix", item.state),
    })));
  }

  return settingsPanel(rows);
}

function removeConfirmationDialog(app, onCancel, onRemove) {
  const overlay = createEl("div", {
    style: `
      position: fixed;
      inset: 0;
      z-index: 1000;
      display: grid;
      place-items: center;
      background: rgba(0, 0, 0, 0.28);
    `,
  });
  const name = app.displayName || app.bundleIdentifier;
  const dialog = createEl("div", {
    style: `
      display: grid;
      gap: 16px;
      width: min(420px, calc(100vw - 40px));
      padding: 18px;
      border: 1px solid var(--token-border, rgba(127, 127, 127, 0.18));
      border-radius: 14px;
      background: var(--token-main-surface-primary, #fff);
      box-shadow: 0 18px 60px rgba(0, 0, 0, 0.24);
    `,
  });
  const copy = createEl("div", {
    style: "display: grid; gap: 6px;",
  });
  copy.append(
    createEl("div", {
      text: `Remove "${name}" from always allowed apps?`,
      style: "font-size: 16px; font-weight: 650; line-height: 1.3;",
    }),
    createEl("div", {
      text: `Codex will ask to use "${name}" in the next computer use session.`,
      style: "color: var(--token-text-secondary, var(--text-secondary, #666)); font-size: 13px; line-height: 1.4;",
    })
  );
  const actions = createEl("div", {
    style: "display: flex; justify-content: flex-end; gap: 8px;",
  });
  const cancel = button("Cancel", "secondary");
  const remove = button("Remove", "danger");
  cancel.addEventListener("click", onCancel);
  remove.addEventListener("click", onRemove);
  actions.append(cancel, remove);
  dialog.append(copy, actions);
  overlay.append(dialog);
  return overlay;
}

function setupDot(state) {
  const dot = createEl("span", {
    style: `
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 28px;
      height: 28px;
      border-radius: 999px;
      background: ${stateColor(state)[1]};
      color: ${stateColor(state)[0]};
      font-size: 13px;
      font-weight: 700;
    `,
  });
  dot.append(statusIcon(state));
  return dot;
}

function statusIcon(state) {
  if (state === "pass") {
    return svgIcon("m5 10 3 3 7-7", "width: 14px; height: 14px;");
  }
  if (state === "fail") {
    return svgIcon("M10 5v6m0 4h.01", "width: 14px; height: 14px;");
  }
  return svgIcon("M10 9v5m0-8h.01", "width: 14px; height: 14px;");
}

function statusPill(text, state) {
  const [color, bg] = stateColor(state);
  return createEl("span", {
    text,
    style: `
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 24px;
      padding: 2px 9px;
      border-radius: 999px;
      background: ${bg};
      color: ${color};
      font-size: 12px;
      font-weight: 600;
      white-space: nowrap;
    `,
  });
}

function statusNote(state, text) {
  const [color, bg] = stateColor(state);
  return createEl("div", {
    text,
    style: `
      border-radius: 8px;
      background: ${bg};
      color: ${color};
      font-size: 12px;
      line-height: 1.35;
      padding: 8px 10px;
    `,
  });
}

function stateColor(state) {
  const colors = {
    pass: ["#0f7b45", "rgba(15, 123, 69, 0.10)"],
    warn: ["#9a5b00", "rgba(154, 91, 0, 0.12)"],
    fail: ["#b42318", "rgba(180, 35, 24, 0.12)"],
    info: ["#2463eb", "rgba(36, 99, 235, 0.10)"],
  };
  return colors[state] || colors.info;
}

function button(text, variant = "secondary") {
  const primary = variant === "primary";
  const danger = variant === "danger";
  const node = createEl("button", {
    text,
    style: `
      appearance: none;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 30px;
      border: 1px solid ${primary ? "#0F172A" : danger ? "#b42318" : "rgba(127, 127, 127, 0.28)"};
      border-radius: 8px;
      background: ${primary ? "#0F172A" : danger ? "#b42318" : "rgba(127, 127, 127, 0.10)"};
      color: ${primary || danger ? "#fff" : "inherit"};
      cursor: pointer;
      font: inherit;
      font-size: 13px;
      font-weight: 500;
      line-height: 18px;
      padding: 5px 10px;
      white-space: nowrap;
    `,
  });
  return node;
}

function createEl(tag, options = {}) {
  const node = document.createElement(tag);
  if (options.text !== undefined) node.textContent = options.text;
  if (options.style) node.setAttribute("style", options.style);
  return node;
}
