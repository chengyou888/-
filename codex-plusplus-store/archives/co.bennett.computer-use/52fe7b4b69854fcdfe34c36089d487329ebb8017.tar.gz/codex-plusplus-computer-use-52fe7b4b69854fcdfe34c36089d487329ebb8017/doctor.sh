#!/bin/sh
set -eu

MARKETPLACE_NAME="openai-bundled"
PLUGIN_CONFIG_SECTION='[plugins."computer-use@openai-bundled"]'
MARKETPLACE_REL="Contents/Resources/plugins/openai-bundled"
PLUGIN_REL="$MARKETPLACE_REL/plugins/computer-use"
CLIENT_REL="$PLUGIN_REL/Codex Computer Use.app/Contents/SharedSupport/SkyComputerUseClient.app/Contents/MacOS/SkyComputerUseClient"
CONFIG_FILE="${CODEX_HOME:-$HOME/.codex}/config.toml"
RUNTIME_MARKETPLACE_ROOT="${CODEX_HOME:-$HOME/.codex}/.tmp/bundled-marketplaces/$MARKETPLACE_NAME"

candidate_apps() {
  ps ax -o command= | while IFS= read -r command; do
    case "$command" in
      "/Applications/Codex.app/Contents/MacOS/Codex"*)
        printf '%s\n' "/Applications/Codex.app"
        ;;
      "/Applications/Codex (Beta).app/Contents/MacOS/Codex (Beta)"*)
        printf '%s\n' "/Applications/Codex (Beta).app"
        ;;
    esac
  done

  printf '%s\n' "/Applications/Codex.app"
  printf '%s\n' "/Applications/Codex (Beta).app"
}

find_codex_app() {
  found_app=""
  while IFS= read -r app; do
    if [ -x "$app/$CLIENT_REL" ] && [ -f "$app/$PLUGIN_REL/.codex-plugin/plugin.json" ]; then
      found_app="$app"
      break
    fi
  done <<EOF
$(candidate_apps | awk '!seen[$0]++')
EOF

  if [ -n "$found_app" ]; then
    printf '%s\n' "$found_app"
    return 0
  fi

  return 1
}

find_codex_bin() {
  found_bin=""
  while IFS= read -r app; do
    if [ -x "$app/Contents/Resources/codex" ]; then
      found_bin="$app/Contents/Resources/codex"
      break
    fi
  done <<EOF
$(candidate_apps | awk '!seen[$0]++')
EOF

  if [ -n "$found_bin" ]; then
    printf '%s\n' "$found_bin"
    return 0
  fi

  if command -v codex >/dev/null 2>&1; then
    command -v codex
    return 0
  fi

  return 1
}

try_official_install() {
  codex_bin="$(find_codex_bin)" || {
    printf '%s\n' "Codex CLI was not found. Install or update Codex Desktop, then run doctor again." >&2
    return 1
  }

  printf '%s\n' "OpenAI Computer Use bundle was not found."
  printf '%s\n' "Trying Codex's official update/install flow:"
  printf '  %s\n' "$codex_bin"

  if "$codex_bin" update; then
    printf '%s\n' "Codex update completed. Re-checking Computer Use bundle..."
  else
    printf '%s\n' "Codex update did not complete. Continuing with installer check..." >&2
  fi

  if find_codex_app >/dev/null 2>&1; then
    return 0
  fi

  printf '%s\n' "Computer Use is still missing after update."
  printf '%s\n' "Opening Codex's official app installer, then re-checking..."
  if "$codex_bin" app; then
    printf '%s\n' "Codex app installer command completed."
  else
    printf '%s\n' "Codex app installer command did not complete." >&2
  fi

  find_codex_app >/dev/null 2>&1
}

ensure_plugin_cache() {
  computer_use_root="$1"
  plugin_json="$computer_use_root/.codex-plugin/plugin.json"
  plugin_version="$(sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$plugin_json" | sed -n '1p')"

  if [ -z "$plugin_version" ]; then
    printf '%s\n' "Unable to read Computer Use plugin version from $plugin_json" >&2
    return 1
  fi

  cache_root="${CODEX_HOME:-$HOME/.codex}/plugins/cache/$MARKETPLACE_NAME/computer-use/$plugin_version"
  cache_client="$cache_root/Codex Computer Use.app/Contents/SharedSupport/SkyComputerUseClient.app/Contents/MacOS/SkyComputerUseClient"

  if [ -x "$cache_client" ] && [ -f "$cache_root/.codex-plugin/plugin.json" ]; then
    printf '%s\n' "Computer Use plugin cache is installed:"
    printf '  %s\n' "$cache_root"
    return 0
  fi

  printf '%s\n' "Installing Computer Use plugin cache from official Codex bundle:"
  printf '  %s\n' "$cache_root"
  mkdir -p "$cache_root"
  /usr/bin/ditto "$computer_use_root" "$cache_root"

  if [ ! -x "$cache_client" ] || [ ! -f "$cache_root/.codex-plugin/plugin.json" ]; then
    printf '%s\n' "Computer Use plugin cache did not verify after install." >&2
    return 1
  fi
}

ensure_runtime_marketplace() {
  marketplace_root="$1"
  runtime_client="$RUNTIME_MARKETPLACE_ROOT/plugins/computer-use/Codex Computer Use.app/Contents/SharedSupport/SkyComputerUseClient.app/Contents/MacOS/SkyComputerUseClient"
  runtime_marketplace="$RUNTIME_MARKETPLACE_ROOT/.agents/plugins/marketplace.json"

  if [ -x "$runtime_client" ] && [ -f "$runtime_marketplace" ] && grep -q '"name": "computer-use"' "$runtime_marketplace"; then
    printf '%s\n' "Runtime bundled marketplace includes Computer Use:"
    printf '  %s\n' "$RUNTIME_MARKETPLACE_ROOT"
    return 0
  fi

  printf '%s\n' "Restoring Computer Use in Codex runtime marketplace:"
  printf '  %s\n' "$RUNTIME_MARKETPLACE_ROOT"
  mkdir -p "$(dirname "$RUNTIME_MARKETPLACE_ROOT")"
  /usr/bin/ditto "$marketplace_root" "$RUNTIME_MARKETPLACE_ROOT"

  if [ ! -x "$runtime_client" ] || ! grep -q '"name": "computer-use"' "$runtime_marketplace"; then
    printf '%s\n' "Runtime bundled marketplace did not verify after restore." >&2
    return 1
  fi
}

ensure_native_plugin_enabled() {
  config_dir="$(dirname "$CONFIG_FILE")"
  mkdir -p "$config_dir"

  if [ ! -f "$CONFIG_FILE" ]; then
    cat > "$CONFIG_FILE" <<EOF
$PLUGIN_CONFIG_SECTION
enabled = true
EOF
    printf '%s\n' "Enabled native Computer Use plugin:"
    printf '  %s\n' "computer-use@openai-bundled"
    return 0
  fi

  tmp="$(mktemp)"
  awk -v target="$PLUGIN_CONFIG_SECTION" '
    function flush_enabled() {
      if (in_target && !enabled_seen) {
        print "enabled = true"
        enabled_seen = 1
      }
    }

    {
      if ($0 ~ /^[[:space:]]*\[/) {
        flush_enabled()
        if ($0 == target) {
          in_target = 1
          seen_target = 1
          enabled_seen = 0
          print
          next
        }
        in_target = 0
      }

      if (in_target && $0 ~ /^[[:space:]]*enabled[[:space:]]*=/) {
        print "enabled = true"
        enabled_seen = 1
        next
      }

      print
    }

    END {
      flush_enabled()
      if (!seen_target) {
        print ""
        print target
        print "enabled = true"
      }
    }
  ' "$CONFIG_FILE" > "$tmp"
  mv "$tmp" "$CONFIG_FILE"

  printf '%s\n' "Enabled native Computer Use plugin:"
  printf '  %s\n' "computer-use@openai-bundled"
}

missing_bundle_error() {
  cat >&2 <<'EOF'
OpenAI Computer Use was not found inside Codex.app or Codex (Beta).app.

Doctor tried Codex's official update/install flow when possible.
If an installer opened, finish it and run doctor again.

Expected official helper location:
  Contents/Resources/plugins/openai-bundled/plugins/computer-use

This tweak does not fetch or redistribute OpenAI's signed helper from unofficial sources.
EOF
  exit 1
}

main() {
  if ! app="$(find_codex_app)"; then
    try_official_install || missing_bundle_error
    app="$(find_codex_app)" || missing_bundle_error
  fi

  codex_bin="$app/Contents/Resources/codex"
  marketplace_root="$app/$MARKETPLACE_REL"
  computer_use_root="$app/$PLUGIN_REL"

  if [ ! -x "$codex_bin" ]; then
    printf '%s\n' "Codex CLI not found at $codex_bin" >&2
    exit 1
  fi

  printf '%s\n' "Found OpenAI Computer Use bundle:"
  printf '  %s\n' "$computer_use_root"
  printf '%s\n' "Registering bundled marketplace:"
  printf '  %s\n' "$marketplace_root"

  ensure_plugin_cache "$computer_use_root"
  ensure_runtime_marketplace "$marketplace_root"

  if output="$("$codex_bin" plugin marketplace add "$marketplace_root" 2>&1)"; then
    printf '%s\n' "$output"
  else
    case "$output" in
      *"already added from a different source"*)
        if [ -f "$CONFIG_FILE" ]; then
          backup="$CONFIG_FILE.backup-computer-use-$(date +%Y%m%d%H%M%S)"
          cp "$CONFIG_FILE" "$backup"
          printf '%s\n' "Backed up existing Codex config:"
          printf '  %s\n' "$backup"
        fi

        "$codex_bin" plugin marketplace remove "$MARKETPLACE_NAME"
        "$codex_bin" plugin marketplace add "$marketplace_root"
        ;;
      *)
        printf '%s\n' "$output" >&2
        exit 1
        ;;
    esac
  fi

  if ! grep -q '"name": "computer-use"' "$marketplace_root/.agents/plugins/marketplace.json"; then
    printf '%s\n' "The registered marketplace does not advertise computer-use." >&2
    exit 1
  fi

  ensure_native_plugin_enabled

  cat <<EOF

Computer Use bundle verified.

Next steps:
  1. Fully quit and reopen Codex Desktop.
  2. In Codex++ settings, make sure this tweak is enabled.
  3. If macOS blocks access, grant Accessibility and Screen Recording to Codex Computer Use and Codex.app.
EOF
}

main "$@"
