#!/bin/sh
set -eu

find_plugin_dir() {
  for app in "/Applications/Codex.app" "/Applications/Codex (Beta).app"; do
    candidate="$app/Contents/Resources/plugins/openai-bundled/plugins/computer-use"
    client="$candidate/Codex Computer Use.app/Contents/SharedSupport/SkyComputerUseClient.app/Contents/MacOS/SkyComputerUseClient"
    if [ -x "$client" ]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done

  return 1
}

PLUGIN_DIR="$(find_plugin_dir)" || {
  printf '%s\n' "OpenAI Computer Use client not found. Run this tweak's Troubleshoot repair or ./doctor.sh to invoke Codex's official updater." >&2
  exit 127
}

CLIENT="$PLUGIN_DIR/Codex Computer Use.app/Contents/SharedSupport/SkyComputerUseClient.app/Contents/MacOS/SkyComputerUseClient"

cd "$PLUGIN_DIR"
exec "$CLIENT" mcp
