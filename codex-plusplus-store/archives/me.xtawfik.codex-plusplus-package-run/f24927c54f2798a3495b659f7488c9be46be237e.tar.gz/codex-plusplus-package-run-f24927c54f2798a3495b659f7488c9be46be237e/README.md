# Package Run

Package Run shows npm scripts directly in Codex's native file viewer when the active right-panel file is `package.json`. Commands are sent into Codex's integrated terminal.

![Package Run screenshot](./screenshot.png)

## Features

- Auto-detects the active right-panel `package.json` file.
- Shows a compact scripts panel in the file viewer canvas.
- Reads scripts from the exact open `package.json` path.
- Lists every script under `package.json > scripts`.
- Detects `pnpm`, `yarn`, `bun`, or `npm`.
- Opens or focuses Codex's bottom terminal panel before sending the command.

## Installation

Copy this folder into your Codex++ tweaks directory:

```text
~/Library/Application Support/codex-plusplus/tweaks/codex-plusplus-package-run
```

Then restart Codex, or reload tweaks if your runtime supports hot reload.

## Notes

- There is no global shortcut or workspace guessing.
- Commands are sent as `cd <package-json-directory> && <package-manager> run <script>`.
- This version targets Codex desktop on macOS first. The terminal injection path is best-effort on other platforms.
