/**
 * Package Run
 *
 * Shows package.json scripts directly inside Codex's native file viewer when
 * the active right-panel file is package.json.
 */

const STYLE_ID = "codexpp-package-run-style";
const PANEL_ATTR = "data-codexpp-package-run-panel";
const MAIN_STATE_KEY = "__codexpp_package_run_main_state__";
const RENDER_STATE_KEY = "__codexpp_package_run_renderer_state__";

/** @type {import("@codex-plusplus/sdk").Tweak} */
module.exports = {
  start(api) {
    if (api.process === "main") {
      globalThis[MAIN_STATE_KEY]?.dispose?.();

      const state = { api, disposers: [] };
      state.dispose = () => stopMain(state);
      globalThis[MAIN_STATE_KEY] = state;
      this._state = state;
      startMain(api, state);
      return;
    }

    globalThis[RENDER_STATE_KEY]?.dispose?.();

    const state = {
      api,
      disposed: false,
      scanTimer: 0,
      scanRetryTimers: [],
      panel: null,
      target: null,
      host: null,
      hostPositionBeforeMount: "",
      changedHostPosition: false,
      packageJsonPath: "",
      result: null,
      loading: false,
      error: "",
      runError: "",
      status: "",
      busyScript: "",
      requestToken: 0,
      statusTimer: null,
      disposers: [],
    };

    state.dispose = () => disposeRendererState(state);
    globalThis[RENDER_STATE_KEY] = state;
    this._state = state;

    startRenderer(api, state);
  },

  stop() {
    this._state?.dispose?.();
  },
};

// ---------------------------------------------------------------- main side

function startMain(api, state) {
  const { ipcMain } = require("electron");
  const channels = getChannels(api);

  for (const channel of Object.values(channels)) {
    try {
      ipcMain.removeHandler(channel);
    } catch {
      // Ignore missing handlers during hot reload.
    }
  }

  ipcMain.handle(channels.getCommands, async (_event, payload = {}) =>
    getPackageScripts(api, payload),
  );
  ipcMain.handle(channels.runCommand, async (event, payload = {}) =>
    runPackageScriptInTerminal(api, event, payload),
  );
  ipcMain.handle(channels.ensureTerminal, async (event) =>
    ensureTerminalPanelVisible(event),
  );

  state.disposers.push(() => {
    for (const channel of Object.values(channels)) {
      try {
        ipcMain.removeHandler(channel);
      } catch {
        // Ignore cleanup races.
      }
    }
  });
}

function stopMain(state) {
  if (globalThis[MAIN_STATE_KEY] === state) {
    delete globalThis[MAIN_STATE_KEY];
  }
  for (const dispose of state.disposers.splice(0).reverse()) {
    try {
      dispose();
    } catch (error) {
      state.api.log.warn("package run main cleanup failed", error);
    }
  }
}

async function getPackageScripts(api, payload = {}) {
  try {
    return await readPackageScripts(payload.packageJsonPath);
  } catch (error) {
    api.log.warn("package run read failed", error);
    return errorFailure(error);
  }
}

async function runPackageScriptInTerminal(api, event, payload = {}) {
  try {
    const scriptName = String(payload.scriptName || "").trim();
    if (!scriptName) {
      return failure("missing_script", "No package script was provided.");
    }

    const result = await readPackageScripts(payload.packageJsonPath);
    if (!result.ok) return result;

    const commandDef = result.commands.find((command) => command.name === scriptName);
    if (!commandDef) {
      return failure(
        "unknown_script",
        `The script "${scriptName}" was not found in this package.json.`,
      );
    }

    const command = buildTerminalCommand(
      result.root,
      result.packageManager,
      scriptName,
    );
    const contents = resolveSenderWebContents(event);
    if (!contents) {
      return failure(
        "terminal_unavailable",
        "Could not access the current Codex window to type into the terminal.",
      );
    }

    contents.focus?.();

    let typed = false;
    if (typeof contents.insertText === "function") {
      const insertResult = contents.insertText(command);
      if (insertResult && typeof insertResult.then === "function") {
        await insertResult;
      }
      typed = true;
    }
    if (!typed) {
      typeTextWithInputEvents(contents, command);
    }

    sendEnter(contents);

    return {
      ok: true,
      root: result.root,
      packageJsonPath: result.packageJsonPath,
      packageManager: result.packageManager,
      command,
      scriptName,
    };
  } catch (error) {
    api.log.warn("package run terminal dispatch failed", error);
    return errorFailure(error);
  }
}

async function readPackageScripts(packageJsonPath) {
  const normalizedPath = normalizePackageJsonPath(packageJsonPath);
  if (!normalizedPath) {
    return failure(
      "invalid_package_path",
      "The active file is not a readable package.json file.",
    );
  }

  const fs = require("node:fs");
  const path = require("node:path");
  const root = path.dirname(normalizedPath);

  let pkg;
  try {
    pkg = JSON.parse(await fs.promises.readFile(normalizedPath, "utf8"));
  } catch (error) {
    if (error?.code === "ENOENT") {
      return failure("missing_package_json", "This package.json no longer exists.");
    }
    if (error instanceof SyntaxError) {
      return failure("invalid_json", `package.json is not valid JSON: ${error.message}`);
    }
    throw error;
  }

  const scripts =
    pkg && typeof pkg.scripts === "object" && !Array.isArray(pkg.scripts)
      ? pkg.scripts
      : {};
  const packageManager = detectPackageManager(root, pkg);

  return {
    ok: true,
    root,
    packageJsonPath: normalizedPath,
    packageManager,
    commands: Object.entries(scripts).map(([name, script]) => ({
      name,
      script: typeof script === "string" ? script : String(script ?? ""),
      runCommand: buildRunnerInvocation(packageManager, name),
    })),
  };
}

function normalizePackageJsonPath(value) {
  const fs = require("node:fs");
  const path = require("node:path");
  const candidate = normalizeLocalPathHint(value);
  if (!candidate || !path.isAbsolute(candidate)) return null;

  const normalized = path.resolve(candidate);
  if (path.basename(normalized) !== "package.json") return null;

  try {
    const stat = fs.statSync(normalized);
    if (!stat.isFile()) return null;
  } catch {
    return null;
  }

  return normalized;
}

function normalizeLocalPathHint(value) {
  const text = String(value || "").trim();
  if (!text) return "";

  if (text.startsWith("file://")) {
    try {
      const { fileURLToPath } = require("node:url");
      return fileURLToPath(text);
    } catch {
      return text;
    }
  }

  if (text.startsWith("local:")) {
    return text.slice("local:".length);
  }

  return text;
}

function detectPackageManager(root, pkg) {
  const fs = require("node:fs");
  const path = require("node:path");

  const rawPackageManager =
    typeof pkg?.packageManager === "string" ? pkg.packageManager.trim() : "";
  const declared = rawPackageManager.split("@")[0].toLowerCase();
  if (declared === "pnpm") return "pnpm";
  if (declared === "yarn") return "yarn";
  if (declared === "bun") return "bun";
  if (declared === "npm") return "npm";

  const files = [
    ["pnpm-lock.yaml", "pnpm"],
    ["yarn.lock", "yarn"],
    ["bun.lockb", "bun"],
    ["bun.lock", "bun"],
    ["package-lock.json", "npm"],
  ];
  for (const [name, manager] of files) {
    if (fs.existsSync(path.join(root, name))) {
      return manager;
    }
  }

  return "npm";
}

function buildRunnerInvocation(packageManager, scriptName) {
  return `${packageManager} run ${shellQuote(scriptName)}`;
}

function buildTerminalCommand(root, packageManager, scriptName) {
  return `cd ${shellQuote(root)} && ${buildRunnerInvocation(packageManager, scriptName)}`;
}

function shellQuote(value) {
  return `'${String(value).replace(/'/g, `'\\''`)}'`;
}

function resolveSenderWebContents(event) {
  const { BrowserWindow, webContents } = require("electron");

  if (event?.sender && !event.sender.isDestroyed?.()) {
    return event.sender;
  }

  const focusedContents = webContents.getFocusedWebContents?.();
  if (focusedContents && !focusedContents.isDestroyed?.()) {
    return focusedContents;
  }

  const focusedWindow = BrowserWindow.getFocusedWindow?.();
  if (focusedWindow?.webContents && !focusedWindow.webContents.isDestroyed?.()) {
    return focusedWindow.webContents;
  }

  return null;
}

function typeTextWithInputEvents(contents, text) {
  for (const char of String(text || "")) {
    contents.sendInputEvent?.({ type: "char", keyCode: char });
  }
}

function sendEnter(contents) {
  contents.sendInputEvent?.({ type: "keyDown", keyCode: "Enter" });
  contents.sendInputEvent?.({ type: "keyUp", keyCode: "Enter" });
}

function ensureTerminalPanelVisible(event) {
  const contents = resolveSenderWebContents(event);
  if (!contents) {
    return failure(
      "terminal_unavailable",
      "Could not access the current Codex window to open the terminal.",
    );
  }

  sendTrustedTerminalToggle(contents);
  return { ok: true };
}

function sendTrustedTerminalToggle(contents) {
  if (!contents || contents.isDestroyed?.()) return;

  try {
    const electron = require("electron");
    const window = electron.BrowserWindow?.fromWebContents?.(contents);
    if (invokeTerminalMenuToggle(electron, window)) return;
  } catch {
    // Fall through to a trusted key event.
  }

  const modifiers = process.platform === "darwin" ? ["meta"] : ["control"];
  contents.sendInputEvent?.({ type: "keyDown", keyCode: "J", modifiers });
  contents.sendInputEvent?.({ type: "keyUp", keyCode: "J", modifiers });
}

function invokeTerminalMenuToggle(electron, window) {
  const menu = electron.Menu?.getApplicationMenu?.();
  if (!menu || !window || window.isDestroyed?.()) return false;

  const items = [];
  const visit = (children) => {
    for (const item of children || []) {
      items.push(item);
      if (item?.submenu?.items) visit(item.submenu.items);
    }
  };
  visit(menu.items);

  const target = items.find((item) => {
    if (!item || typeof item.click !== "function" || item.enabled === false) {
      return false;
    }
    const label = normalizeMainText(
      `${item.label || ""} ${item.sublabel || ""} ${item.role || ""}`,
    );
    const accelerator = String(item.accelerator || "");
    if (
      label.includes("terminal") &&
      /\b(toggle|show|hide|open|panel|pane|terminal)\b/i.test(label)
    ) {
      return true;
    }
    return /(?:CommandOrControl|Cmd|Command|Control)\+J/i.test(accelerator);
  });
  if (!target) return false;

  try {
    window.show?.();
    window.focus?.();
  } catch {
    // Ignore window focus failures.
  }

  try {
    target.click(target, window, {
      type: "keyDown",
      modifiers: process.platform === "darwin" ? ["meta"] : ["control"],
      keyCode: "J",
    });
    return true;
  } catch {
    return false;
  }
}

function normalizeMainText(value) {
  return String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
}

// ------------------------------------------------------------- renderer side

function startRenderer(_api, state) {
  installStyles();

  const scan = () => scheduleScan(state);
  state.disposers.push(addWindowListener("focus", scan, true));
  state.disposers.push(addDocumentListener("visibilitychange", scan, true));
  state.disposers.push(addDocumentListener("pointerup", scan, true));

  scheduleInitialScans(state);
}

function disposeRendererState(state) {
  state.disposed = true;
  if (globalThis[RENDER_STATE_KEY] === state) {
    delete globalThis[RENDER_STATE_KEY];
  }
  if (state.scanTimer) {
    window.clearTimeout(state.scanTimer);
    state.scanTimer = 0;
  }
  for (const timer of state.scanRetryTimers.splice(0)) {
    window.clearTimeout(timer);
  }
  if (state.statusTimer) {
    window.clearTimeout(state.statusTimer);
    state.statusTimer = null;
  }
  for (const dispose of state.disposers.splice(0).reverse()) {
    try {
      dispose();
    } catch {
      // Ignore listener cleanup races.
    }
  }

  unmountPanel(state);
  removeStylesIfUnused();
}

function scheduleScan(state) {
  if (state.disposed || state.scanTimer) return;
  state.scanTimer = window.setTimeout(() => {
    state.scanTimer = 0;
    scanActivePackageJson(state);
  }, 80);
}

function scheduleInitialScans(state) {
  for (const delay of [0, 180, 500, 1200, 2500, 5000]) {
    const timer = window.setTimeout(() => {
      state.scanRetryTimers = state.scanRetryTimers.filter((id) => id !== timer);
      scheduleScan(state);
    }, delay);
    state.scanRetryTimers.push(timer);
  }
}

function scanActivePackageJson(state) {
  if (state.disposed) return;

  const target = findActivePackageJsonTarget();
  if (!target) {
    unmountPanel(state);
    return;
  }

  if (
    state.panel &&
    state.panel.isConnected &&
    state.packageJsonPath === target.path &&
    state.target?.host === target.host
  ) {
    return;
  }

  mountPanel(state, target);
}

function findActivePackageJsonTarget() {
  const panel = document.querySelector(
    '[data-app-shell-focus-area="right-panel"]',
  );
  if (!(panel instanceof HTMLElement)) return null;

  const tabPath = findActiveTabPath(panel);
  const review = tabPath
    ? findReviewElement(panel, tabPath)
    : findPackageJsonReviewElement(panel);
  const sourcePath = tabPath || review?.getAttribute("data-review-path");
  if (!sourcePath || !sourcePath.startsWith("/") || !isPackageJsonPath(sourcePath)) {
    return null;
  }

  const host =
    review instanceof HTMLElement
      ? findEditorHost(review)
      : findFileViewerHost(panel);
  if (!(host instanceof HTMLElement)) return null;

  if (
    host.dataset.codexppFileEditorSourcePath &&
    host.dataset.codexppFileEditorSourcePath !== sourcePath
  ) {
    delete host.dataset.codexppFileEditorSourcePath;
    delete host.dataset.codexppFileEditorPathOverride;
  }

  const overridePath = host.dataset.codexppFileEditorPathOverride;
  const path =
    overridePath && overridePath.startsWith("/") ? overridePath : sourcePath;

  return { panel, path, sourcePath, review, host };
}

function findActiveTabPath(panel) {
  const activeButton = panel.querySelector(
    '[data-app-shell-tab-controller="right"][data-tab-id^="file:"] button[role="tab"][aria-selected="true"]',
  );
  const active =
    activeButton instanceof HTMLElement
      ? activeButton.closest(
          '[data-app-shell-tab-controller="right"][data-tab-id^="file:"]',
        )
      : panel.querySelector(
          '[data-app-shell-tab-controller="right"][data-tab-id^="file:"]',
        );
  if (!(active instanceof HTMLElement)) return null;
  return pathFromTabId(active.getAttribute("data-tab-id"));
}

function pathFromTabId(tabId) {
  if (!tabId || !tabId.startsWith("file:")) return null;
  let raw = tabId.slice("file:".length);
  if (raw.startsWith("local:")) raw = raw.slice("local:".length);
  try {
    return decodeURIComponent(raw);
  } catch {
    return raw;
  }
}

function findReviewElement(panel, filePath) {
  const escaped = cssEscape(filePath);
  return panel.querySelector(`[data-review-path="${escaped}"]`);
}

function findPackageJsonReviewElement(panel) {
  const reviews = Array.from(panel.querySelectorAll("[data-review-path]"));
  for (let index = reviews.length - 1; index >= 0; index -= 1) {
    const review = reviews[index];
    if (!(review instanceof HTMLElement)) continue;
    if (review.closest(`[${PANEL_ATTR}="true"]`)) continue;
    const filePath = review.getAttribute("data-review-path");
    if (filePath && isPackageJsonPath(filePath)) return review;
  }
  return null;
}

function findEditorHost(review) {
  return (
    review.closest(".h-full.overflow-auto") ||
    review.closest("[role='tabpanel']") ||
    review.parentElement
  );
}

function findFileViewerHost(panel) {
  return (
    panel.querySelector("[role='tabpanel']") ||
    panel.querySelector(".h-full.overflow-auto") ||
    panel
  );
}

function isPackageJsonPath(filePath) {
  return String(filePath || "").split(/[\\/]/).pop() === "package.json";
}

function mountPanel(state, target) {
  unmountPanel(state);

  const panel = document.createElement("div");
  panel.setAttribute(PANEL_ATTR, "true");
  panel.addEventListener("pointerdown", stopPanelEvent);
  panel.addEventListener("mousedown", stopPanelEvent);
  panel.addEventListener("click", stopPanelEvent);

  state.target = target;
  state.host = target.host;
  state.packageJsonPath = target.path;
  state.result = null;
  state.error = "";
  state.runError = "";
  state.status = "";
  state.loading = true;
  state.busyScript = "";
  state.hostPositionBeforeMount = target.host.style.position;
  state.changedHostPosition = false;

  if (window.getComputedStyle(target.host).position === "static") {
    target.host.style.position = "relative";
    state.changedHostPosition = true;
  }

  target.host.appendChild(panel);
  state.panel = panel;

  renderPanel(state);
  void refreshPackageScripts(state, target.path);
}

function unmountPanel(state) {
  if (!state.panel && !state.host && !state.packageJsonPath) return;

  if (state.statusTimer) {
    window.clearTimeout(state.statusTimer);
    state.statusTimer = null;
  }
  if (state.panel) {
    state.panel.remove();
  }
  if (state.host && state.changedHostPosition) {
    state.host.style.position = state.hostPositionBeforeMount;
  }
  state.panel = null;
  state.target = null;
  state.host = null;
  state.hostPositionBeforeMount = "";
  state.changedHostPosition = false;
  state.packageJsonPath = "";
  state.result = null;
  state.loading = false;
  state.error = "";
  state.runError = "";
  state.status = "";
  state.busyScript = "";
  state.requestToken += 1;
}

async function refreshPackageScripts(state, packageJsonPath) {
  if (state.disposed || !state.panel) return;

  const token = ++state.requestToken;
  state.loading = true;
  state.error = "";
  state.runError = "";
  renderPanel(state);

  try {
    const response = await state.api.ipc.invoke("get-commands", {
      packageJsonPath,
    });
    if (
      state.disposed ||
      token !== state.requestToken ||
      state.packageJsonPath !== packageJsonPath
    ) {
      return;
    }

    state.result = response;
    state.error = response?.ok ? "" : response?.message || "Could not read scripts.";
  } catch (error) {
    if (
      state.disposed ||
      token !== state.requestToken ||
      state.packageJsonPath !== packageJsonPath
    ) {
      return;
    }
    state.result = null;
    state.error = error?.message || String(error);
  } finally {
    if (
      !state.disposed &&
      token === state.requestToken &&
      state.packageJsonPath === packageJsonPath
    ) {
      state.loading = false;
      renderPanel(state);
    }
  }
}

function renderPanel(state) {
  const panel = state.panel;
  if (!panel) return;
  panel.replaceChildren();

  const header = document.createElement("div");
  header.className = "codexpp-package-run-header";

  const titleWrap = document.createElement("div");
  titleWrap.className = "codexpp-package-run-title-wrap";

  const title = document.createElement("div");
  title.className = "codexpp-package-run-title";
  title.textContent = "Scripts";

  const subtitle = document.createElement("div");
  subtitle.className = "codexpp-package-run-subtitle";
  const rootPath = state.result?.ok ? state.result.root : dirnameFromPackageJsonPath(state.packageJsonPath);
  subtitle.textContent = truncateMiddle(rootPath || "package.json", 38);

  titleWrap.append(title, subtitle);

  header.appendChild(titleWrap);
  panel.appendChild(header);

  const body = document.createElement("div");
  body.className = "codexpp-package-run-body";
  panel.appendChild(body);

  if (state.loading) {
    body.appendChild(createMessage("Loading scripts...", "muted"));
    return;
  }

  if (state.error) {
    body.appendChild(createMessage(state.error, "error"));
    return;
  }

  const commands = Array.isArray(state.result?.commands)
    ? state.result.commands
    : [];

  if (commands.length === 0) {
    body.appendChild(createMessage("No scripts in this package.json.", "muted"));
    return;
  }

  if (state.runError) {
    body.appendChild(createMessage(state.runError, "error"));
  } else if (state.status) {
    body.appendChild(createMessage(state.status, "status"));
  }

  const list = document.createElement("div");
  list.className = "codexpp-package-run-list";
  for (const command of commands) {
    list.appendChild(createCommandButton(state, command));
  }
  body.appendChild(list);
}

function createCommandButton(state, command) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "codexpp-package-run-item";
  button.disabled = Boolean(state.busyScript);

  const name = document.createElement("span");
  name.className = "codexpp-package-run-item-name";
  name.textContent =
    state.busyScript === command.name ? `${command.name} running...` : command.name;

  const detail = document.createElement("span");
  detail.className = "codexpp-package-run-item-detail";
  detail.textContent = command.runCommand;

  button.append(name, detail);
  button.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    void runCommandFromPanel(state, command);
  });

  return button;
}

function createMessage(text, type) {
  const message = document.createElement("div");
  message.className = `codexpp-package-run-message codexpp-package-run-message-${type}`;
  message.textContent = text;
  return message;
}

async function runCommandFromPanel(state, command) {
  if (state.busyScript || !state.packageJsonPath) return;

  const packageJsonPath = state.packageJsonPath;
  state.busyScript = command.name;
  state.runError = "";
  state.status = "";
  renderPanel(state);

  try {
    const ready = await ensureTerminalReady();
    if (!ready.ok) {
      state.runError = ready.message || "Codex's terminal could not be opened.";
      return;
    }

    const response = await state.api.ipc.invoke("run-command", {
      packageJsonPath,
      scriptName: command.name,
    });

    if (state.packageJsonPath !== packageJsonPath || state.disposed) return;

    if (!response?.ok) {
      state.runError = response?.message || "Could not run the selected script.";
      return;
    }

    state.status = `Sent ${command.name} to terminal.`;
    if (state.statusTimer) window.clearTimeout(state.statusTimer);
    state.statusTimer = window.setTimeout(() => {
      if (state.packageJsonPath === packageJsonPath && state.status) {
        state.status = "";
        renderPanel(state);
      }
    }, 1800);
  } catch (error) {
    if (state.packageJsonPath === packageJsonPath && !state.disposed) {
      state.runError = error?.message || String(error);
    }
  } finally {
    if (state.packageJsonPath === packageJsonPath && !state.disposed) {
      state.busyScript = "";
      renderPanel(state);
    }
  }
}

async function ensureTerminalReady() {
  let textarea = findTerminalTextarea();
  if (!textarea) {
    await invokeTerminalReveal();
    await waitFor(() => findTerminalTextarea() || findBottomPanel(), 2600);
  }

  textarea = findTerminalTextarea();
  if (!textarea) {
    await invokeTerminalReveal();
    await waitFor(() => findTerminalTextarea(), 1800);
  }

  textarea = findTerminalTextarea();
  if (!textarea) {
    const newTerminalButton = findNewTerminalButton();
    if (newTerminalButton) {
      clickElement(newTerminalButton);
      await waitFor(() => findTerminalTextarea(), 1800);
    }
  }

  textarea = findTerminalTextarea();
  if (!textarea) {
    return failure(
      "terminal_unavailable",
      "Codex's terminal could not be opened or focused.",
    );
  }

  focusTerminalTextarea(textarea);
  await wait(75);
  return { ok: true };
}

async function invokeTerminalReveal() {
  try {
    const response = await globalThis[RENDER_STATE_KEY]?.api?.ipc?.invoke?.(
      "ensure-terminal",
    );
    if (response?.ok) return true;
  } catch {
    // Fall back to DOM-level controls below.
  }
  return clickTerminalToggleButton() || dispatchTerminalShortcut();
}

function clickTerminalToggleButton() {
  const nodes = document.querySelectorAll("button, [role='button']");
  for (const node of nodes) {
    if (!(node instanceof HTMLElement) || !isVisible(node)) continue;
    const label = normalizeText(
      node.getAttribute("aria-label") ||
        node.getAttribute("title") ||
        node.textContent ||
        "",
    );
    if (/\btoggle terminal\b/.test(label) || label === "terminal") {
      clickElement(node);
      return true;
    }
  }
  return false;
}

function dispatchTerminalShortcut() {
  const isMac = navigator.platform.toLowerCase().includes("mac");
  for (const target of [window, document, document.body]) {
    target.dispatchEvent(
      new KeyboardEvent("keydown", {
        bubbles: true,
        cancelable: true,
        composed: true,
        key: "j",
        code: "KeyJ",
        keyCode: 74,
        which: 74,
        metaKey: isMac,
        ctrlKey: !isMac,
      }),
    );
    target.dispatchEvent(
      new KeyboardEvent("keyup", {
        bubbles: true,
        cancelable: true,
        composed: true,
        key: "j",
        code: "KeyJ",
        keyCode: 74,
        which: 74,
        metaKey: isMac,
        ctrlKey: !isMac,
      }),
    );
  }
  return true;
}

function findBottomPanel() {
  const panel = document.querySelector('[data-app-shell-focus-area="bottom-panel"]');
  return panel instanceof HTMLElement && isVisible(panel) ? panel : null;
}

function findTerminalTextarea() {
  const selectors = [
    '[data-app-shell-focus-area="bottom-panel"] .xterm-helper-textarea',
    '[data-app-shell-focus-area="bottom-panel"] .xterm textarea',
    '[data-app-shell-focus-area="bottom-panel"] textarea[aria-label="Terminal input"]',
    '[data-codex-terminal] textarea[aria-label="Terminal input"]',
    '[id^="terminal-panel-"] textarea[aria-label="Terminal input"]',
    'textarea[aria-label="Terminal input"]',
    ".xterm-helper-textarea",
  ];
  for (const selector of selectors) {
    const node = document.querySelector(selector);
    if (node instanceof HTMLTextAreaElement && isTerminalTextareaUsable(node)) {
      return node;
    }
  }
  return null;
}

function isTerminalTextareaUsable(node) {
  if (!node.isConnected || node.disabled || node.readOnly) return false;
  const style = window.getComputedStyle(node);
  if (style.display === "none" || style.visibility === "hidden") return false;

  const root = node.closest(
    '[data-app-shell-focus-area="bottom-panel"], [data-codex-terminal], [id^="terminal-panel-"], .xterm',
  );
  return root instanceof HTMLElement;
}

function findNewTerminalButton() {
  const panel = findBottomPanel();
  if (!panel) return null;
  const nodes = panel.querySelectorAll("button, [role='button']");
  for (const node of nodes) {
    if (!(node instanceof HTMLElement) || !isVisible(node)) continue;
    const label = normalizeText(
      node.getAttribute("aria-label") ||
        node.getAttribute("title") ||
        node.textContent ||
        "",
    );
    if (label === "new terminal" || label.includes("new terminal")) {
      return node;
    }
  }
  return null;
}

function focusTerminalTextarea(textarea) {
  const xterm = textarea.closest(".xterm");
  if (xterm instanceof HTMLElement) {
    clickElement(xterm);
  }
  textarea.focus({ preventScroll: true });
}

function clickElement(node) {
  if (!(node instanceof HTMLElement)) return;
  const down = { bubbles: true, cancelable: true, button: 0, buttons: 1 };
  if (typeof PointerEvent === "function") {
    node.dispatchEvent(new PointerEvent("pointerdown", down));
  }
  node.dispatchEvent(new MouseEvent("mousedown", down));
  if (typeof PointerEvent === "function") {
    node.dispatchEvent(new PointerEvent("pointerup", down));
  }
  node.dispatchEvent(new MouseEvent("mouseup", down));
  node.click();
}

function stopPanelEvent(event) {
  event.stopPropagation();
}

function addWindowListener(type, listener, options) {
  window.addEventListener(type, listener, options);
  return () => window.removeEventListener(type, listener, options);
}

function addDocumentListener(type, listener, options) {
  document.addEventListener(type, listener, options);
  return () => document.removeEventListener(type, listener, options);
}

function dirnameFromPackageJsonPath(filePath) {
  const text = String(filePath || "");
  const index = Math.max(text.lastIndexOf("/"), text.lastIndexOf("\\"));
  return index > 0 ? text.slice(0, index) : text;
}

function truncateMiddle(value, maxLength) {
  const text = String(value || "");
  if (text.length <= maxLength) return text;
  const marker = "...";
  const remaining = Math.max(0, maxLength - marker.length);
  const front = Math.ceil(remaining / 2);
  const back = Math.floor(remaining / 2);
  return `${text.slice(0, front)}${marker}${text.slice(text.length - back)}`;
}

function normalizeText(value) {
  return String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
}

function cssEscape(value) {
  if (typeof CSS !== "undefined" && typeof CSS.escape === "function") {
    return CSS.escape(value);
  }
  return String(value).replace(/["\\]/g, "\\$&");
}

function isVisible(node) {
  if (!(node instanceof HTMLElement)) return false;
  const rect = node.getBoundingClientRect();
  if (rect.width <= 0 || rect.height <= 0) return false;
  const style = window.getComputedStyle(node);
  return style.visibility !== "hidden" && style.display !== "none";
}

function wait(ms) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

async function waitFor(predicate, timeoutMs) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const value = predicate();
    if (value) return value;
    await wait(50);
  }
  return predicate();
}

function installStyles() {
  document.getElementById(STYLE_ID)?.remove();

  const style = document.createElement("style");
  style.id = STYLE_ID;
  style.textContent = `
    [${PANEL_ATTR}="true"] {
      position: absolute !important;
      top: 0.625rem !important;
      right: 0.625rem !important;
      z-index: 40 !important;
      box-sizing: border-box !important;
      width: min(15.5rem, calc(100% - 1.25rem)) !important;
      max-height: min(22rem, calc(100% - 1.25rem)) !important;
      overflow: auto !important;
      padding: 0.5rem !important;
      border-radius: 0.75rem !important;
      border: 1px solid rgba(255, 255, 255, 0.12) !important;
      background: var(--color-token-background-elevated, #181818) !important;
      color: var(--color-token-text-primary, currentColor) !important;
      font-family: inherit !important;
      pointer-events: auto !important;
    }

    .codexpp-package-run-header {
      display: flex !important;
      align-items: flex-start !important;
      gap: 0.45rem !important;
    }

    .codexpp-package-run-title-wrap {
      min-width: 0 !important;
    }

    .codexpp-package-run-title {
      color: var(--color-token-text-primary, currentColor) !important;
      font-size: 0.82rem !important;
      line-height: 1.2 !important;
      font-weight: 650 !important;
    }

    .codexpp-package-run-subtitle {
      margin-top: 0.1rem !important;
      color: var(--color-token-text-tertiary, currentColor) !important;
      font-size: 0.65rem !important;
      line-height: 1.25 !important;
      white-space: nowrap !important;
      overflow: hidden !important;
      text-overflow: clip !important;
    }

    .codexpp-package-run-body {
      display: grid !important;
      gap: 0.35rem !important;
      margin-top: 0.45rem !important;
    }

    .codexpp-package-run-list {
      display: grid !important;
      gap: 0.12rem !important;
    }

    .codexpp-package-run-item {
      appearance: none !important;
      display: grid !important;
      gap: 0.08rem !important;
      width: 100% !important;
      border: 0 !important;
      border-radius: 0.5rem !important;
      background: transparent !important;
      color: inherit !important;
      cursor: pointer !important;
      padding: 0.38rem 0.45rem !important;
      text-align: left !important;
      transition: background-color 120ms ease, opacity 120ms ease !important;
    }

    .codexpp-package-run-item:hover,
    .codexpp-package-run-item:focus-visible {
      background: rgba(255, 255, 255, 0.08) !important;
      outline: none !important;
    }

    .codexpp-package-run-item:disabled {
      cursor: default !important;
      opacity: 0.7 !important;
    }

    .codexpp-package-run-item-name {
      color: var(--color-token-text-primary, currentColor) !important;
      font-size: 0.76rem !important;
      line-height: 1.2 !important;
      font-weight: 650 !important;
      overflow: hidden !important;
      text-overflow: ellipsis !important;
      white-space: nowrap !important;
    }

    .codexpp-package-run-item-detail {
      color: var(--color-token-text-tertiary, currentColor) !important;
      font-size: 0.64rem !important;
      line-height: 1.25 !important;
      overflow: hidden !important;
      text-overflow: ellipsis !important;
      white-space: nowrap !important;
    }

    .codexpp-package-run-message {
      border-radius: 0.5rem !important;
      font-size: 0.68rem !important;
      line-height: 1.35 !important;
      padding: 0.4rem 0.45rem !important;
    }

    .codexpp-package-run-message-muted {
      color: var(--color-token-text-tertiary, currentColor) !important;
      background: rgba(255, 255, 255, 0.05) !important;
    }

    .codexpp-package-run-message-error {
      color: var(--color-token-status-error, #ff6b6b) !important;
      background: rgba(255, 107, 107, 0.12) !important;
    }

    .codexpp-package-run-message-status {
      color: var(--color-token-status-success, #7ddc9a) !important;
      background: rgba(125, 220, 154, 0.1) !important;
    }
  `;
  document.head.appendChild(style);
}

function removeStylesIfUnused() {
  if (document.querySelector(`[${PANEL_ATTR}="true"]`)) return;
  document.getElementById(STYLE_ID)?.remove();
}

// ---------------------------------------------------------------- utilities

function getChannels(api) {
  const id = api?.manifest?.id || "co.bennett.package-run";
  return {
    getCommands: `codexpp:${id}:get-commands`,
    runCommand: `codexpp:${id}:run-command`,
    ensureTerminal: `codexpp:${id}:ensure-terminal`,
  };
}

function failure(code, message) {
  return { ok: false, code, message };
}

function errorFailure(error) {
  return failure(
    error?.code || "error",
    error?.message || error?.stack || String(error),
  );
}
