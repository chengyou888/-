/**
 * Codex Follow-up
 *
 * Renderer: turns a structured JSON block emitted by Codex into an
 * OpenWebUI-style follow-up panel under assistant messages.
 *
 * Main: syncs the AGENTS.md instruction that tells Codex when/how to emit
 * that structured JSON block.
 */

const TWEAK_ID = "co.Arconte112.followup";
const LEGACY_TWEAK_ID = "co.codex.followup";
const OLDEST_TWEAK_ID = "co.soren.radar-followups";
const PANEL_ATTR = "data-soren-radar-panel";
const HIDDEN_ATTR = "data-soren-radar-hidden";
const STYLE_ID = "soren-radar-followups-style";
const IPC_SYNC_AGENTS = "soren-radar:sync-agents";
const IPC_DEFAULTS = "soren-radar:defaults";
const MAIN_SERVICE_KEY = "__codexFollowupService";
const MAIN_HANDLER_KEY = "__codexFollowupHandlers";
const BLOCK_BEGIN = `<!-- codex-plusplus:${TWEAK_ID}:start -->`;
const BLOCK_END = `<!-- codex-plusplus:${TWEAK_ID}:end -->`;
const LEGACY_BLOCK_BEGIN = `<!-- codex-plusplus:${LEGACY_TWEAK_ID}:start -->`;
const LEGACY_BLOCK_END = `<!-- codex-plusplus:${LEGACY_TWEAK_ID}:end -->`;
const OLDEST_BLOCK_BEGIN = `<!-- codex-plusplus:${OLDEST_TWEAK_ID}:start -->`;
const OLDEST_BLOCK_END = `<!-- codex-plusplus:${OLDEST_TWEAK_ID}:end -->`;

const DEFAULT_FOLLOWUP_PROMPT = [
  "## TWEAKS: Codex Follow-up",
  "",
  "Always include a Follow-up payload at the end of every final assistant response.",
  "",
  "Generate exactly 4 follow-up items by default. Use 5 only when the context clearly has more high-value continuations.",
  "",
  "Prioritize usefulness over variety. Every item must be grounded in the current conversation, user intent, visible work, files, decisions, blockers, people, projects, dates, money, or risks.",
  "",
  "Each item should be one of:",
  "- a concrete next action the user can ask Codex to perform",
  "- a verification step that confirms the work actually succeeded",
  "- an unresolved decision or tradeoff worth resolving",
  "- a context-aware continuation that saves the user effort",
  "",
  "Avoid generic filler such as \"Let me know if you need anything else\", \"Review the changes\", \"Ask another question\", or broad suggestions that could apply to any conversation.",
  "",
  "Each item needs only `prompt`: a concise, specific instruction that can be inserted into the composer and sent directly.",
  "",
  "The prompt should be short enough to scan in the Follow-up panel, but specific enough to tell Codex exactly what to do next.",
  "",
  "For very small or factual answers, still produce 4 items, but make them practical: clarify, verify, apply, compare, summarize, or continue from the user's likely intent.",
  "",
  "Keep the main answer focused. Put follow-up-only information only in the Follow-up payload, not repeated in the visible prose.",
].join("\n");

const LOCKED_FORMAT_INSTRUCTION = [
  "## LOCKED TWEAK FORMAT: Codex Follow-up",
  "",
  "Do not edit or remove this locked section manually. It is required by the Codex++ Follow-up tweak.",
  "",
  "For every final assistant response, append exactly one fenced JSON block at the very end. Do not emit this payload in reasoning, progress updates, tool logs, drafts, or intermediate messages.",
  "",
  "The visible answer must not repeat information that is meant only for Follow-up. If a detail belongs in Follow-up, put it only in the payload.",
  "",
  "Required payload format:",
  "",
  "```json",
  "{",
  '  "codex_follow_up": true,',
  '  "title": "Follow-up",',
  '  "items": [',
  "    {",
  '      "prompt": "Specific follow-up instruction the user can click and send"',
  "    }",
  "  ]",
  "}",
  "```",
  "",
  "Rules: always emit the JSON block in final assistant responses; use 1 to 5 items; each prompt must be concise and useful; do not explain that the JSON exists.",
].join("\n");

const DEFAULT_AGENTS_INSTRUCTION = composeAgentsInstruction(DEFAULT_FOLLOWUP_PROMPT);

module.exports = {
  start(api) {
    if (api.process === "main") {
      startMain(api);
      return;
    }
    if (api.process !== "renderer") return;
    startRenderer.call(this, api);
  },

  stop() {
    const state = this._state;
    if (!state) return;
    state.disposed = true;
    state.observer?.disconnect();
    if (state.interval) window.clearInterval(state.interval);
    window.removeEventListener("focus", state.scheduleScan);
    document.removeEventListener("visibilitychange", state.scheduleScan);
    state.pageHandle?.unregister?.();
    clearPanels();
    document.getElementById(STYLE_ID)?.remove();
  },
};

function startMain(api) {
  const service = createAgentsSyncService(api);
  globalThis[MAIN_SERVICE_KEY] = service;

  if (!globalThis[MAIN_HANDLER_KEY]) {
    api.ipc.handle(IPC_SYNC_AGENTS, (settings = {}) => {
      const active = globalThis[MAIN_SERVICE_KEY];
      return active?.syncAgentsInstruction(settings) || {
        ok: false,
        error: "Follow-up service unavailable",
      };
    });

    api.ipc.handle(IPC_DEFAULTS, () => {
      const active = globalThis[MAIN_SERVICE_KEY];
      return {
        agentsPath: active?.getAgentsPath?.() || "",
        prompt: DEFAULT_FOLLOWUP_PROMPT,
        instruction: DEFAULT_AGENTS_INSTRUCTION,
      };
    });

    globalThis[MAIN_HANDLER_KEY] = true;
  }

  api.log.info("Codex Follow-up main provider active");
}

function startRenderer(api) {
  const state = {
    api,
    enabled: api.storage.get("enabled", true),
    showDivider: api.storage.get("showDivider", true),
    clickableItems: api.storage.get("clickableItems", true),
    title: migrateTitle(api.storage.get("title", "Follow-up")),
    syncAgents: api.storage.get("syncAgents", true),
    followupPrompt: api.storage.get(
      "followupPrompt",
      migrateOldInstruction(api.storage.get("agentsInstruction", "")),
    ),
    observer: null,
    interval: null,
    disposed: false,
    scheduled: false,
    pageHandle: null,
    statusEl: null,
  };

  if (typeof api.settings?.registerPage === "function") {
    state.pageHandle = api.settings.registerPage({
      id: "main",
      title: "Follow-up",
      description: "Render clickable follow-ups under assistant messages.",
      iconSvg:
        '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
        '<circle cx="10" cy="10" r="6.5" stroke="currentColor" stroke-width="1.4"/>' +
        '<circle cx="10" cy="10" r="2" fill="currentColor"/>' +
        '<path d="M10 3.5v2M10 14.5v2M3.5 10h2M14.5 10h2" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/>' +
        "</svg>",
      render: (root) => renderSettings(root, state),
    });
  }

  const scheduleScan = () => {
    if (state.disposed || state.scheduled) return;
    state.scheduled = true;
    requestAnimationFrame(() => {
      state.scheduled = false;
      if (!state.disposed) scanMessages(state);
    });
  };

  state.scheduleScan = scheduleScan;
  injectStyles();
  scheduleScan();

  state.observer = new MutationObserver(scheduleScan);
  state.observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true,
  });
  state.interval = window.setInterval(scheduleScan, 3_000);
  window.addEventListener("focus", scheduleScan);
  document.addEventListener("visibilitychange", scheduleScan);

  this._state = state;

  if (state.syncAgents) {
    window.setTimeout(() => syncAgentsInstruction(state, { quiet: true }), 1_500);
  }

  api.log.info("Codex Follow-up renderer active");
}

function scanMessages(state) {
  if (!state.enabled) {
    clearPanels();
    return;
  }

  const messageNodes = document.querySelectorAll("div.group.flex.min-w-0.flex-col");
  for (const node of messageNodes) {
    if (!(node instanceof HTMLElement)) continue;
    const markdown = node.querySelector(
      "._markdownContent_1rhk1_42, [class*='_markdownContent_']",
    );
    if (!(markdown instanceof HTMLElement)) continue;

    const payload = findRadarPayload(markdown);
    const existing = node.querySelector(`[${PANEL_ATTR}]`);

    if (!payload) {
      existing?.remove();
      continue;
    }

    const items = Array.isArray(payload.items)
      ? payload.items
      .map(normalizeFollowupItem)
      .filter((item) => item.prompt)
        .slice(0, 5)
      : [];

    if (items.length === 0 && !payload.pending) {
      existing?.remove();
      continue;
    }

    const title = cleanPanelTitle(payload.title, state.title);
    const signature = JSON.stringify({
      title,
      items: items.map((item) => item.prompt),
      showDivider: state.showDivider,
      clickableItems: state.clickableItems,
      pending: !!payload.pending,
    });

    if (existing?.dataset.signature === signature) continue;

    const panel = renderRadarPanel({
      title,
      items,
      showDivider: state.showDivider,
      clickableItems: state.clickableItems,
      pending: !!payload.pending,
    });
    panel.dataset.signature = signature;

    if (existing) existing.replaceWith(panel);
    else node.appendChild(panel);
  }
}

function findRadarPayload(markdown) {
  const candidates = [];

  for (const code of markdown.querySelectorAll("pre, code")) {
    if (!(code instanceof HTMLElement)) continue;
    const text = (code.textContent || "").trim();
    if (!text || !/codex_follow_up|soren_radar|follow_ups/.test(text)) continue;
    const parsed = parseRadarJson(text);
    if (parsed) {
      hideSourceBlock(code, markdown, text);
      candidates.push(parsed);
      continue;
    }

    const partial = parsePartialFollowupPayload(text);
    if (partial) {
      hideSourceBlock(code, markdown, text);
      candidates.push(partial);
    }
  }

  if (candidates.length > 0) return candidates[candidates.length - 1];

  const text = markdown.textContent || "";
  const directiveMatch = text.match(/::soren-radar\s*(\{[\s\S]*?\})\s*::/i);
  if (directiveMatch) {
    const parsed = parseRadarJson(directiveMatch[1]);
    if (parsed) return parsed;
  }

  return null;
}

function parseRadarJson(text) {
  const cleaned = text
    .replace(/^```(?:json)?/i, "")
    .replace(/```$/i, "")
    .trim();

  const attempts = [cleaned];
  const firstBrace = cleaned.indexOf("{");
  const lastBrace = cleaned.lastIndexOf("}");
  if (firstBrace >= 0 && lastBrace > firstBrace) {
    attempts.push(cleaned.slice(firstBrace, lastBrace + 1));
  }

  for (const attempt of attempts) {
    try {
      const parsed = JSON.parse(attempt);
      const normalized = normalizePayload(parsed);
      if (normalized) {
        return normalized;
      }
    } catch {
      // Keep trying relaxed slices.
    }
  }

  return null;
}

function parsePartialFollowupPayload(text) {
  if (!/"codex_follow_up"\s*:\s*true/.test(text)) return null;

  return {
    title: extractPartialTitle(text) || "Follow-up",
    items: extractPartialItems(text),
    pending: true,
  };
}

function extractPartialTitle(text) {
  const match = String(text).match(/"title"\s*:\s*"([^"]{1,80})"/);
  return match?.[1]?.trim() || "";
}

function extractPartialItems(text) {
  const items = [];
  const promptPattern = /"prompt"\s*:\s*"([^"]+)"/g;
  let match;

  while ((match = promptPattern.exec(text)) && items.length < 5) {
    const prompt = match[1]?.trim();
    if (prompt) items.push({ prompt });
  }

  if (items.length > 0) return items;

  // Backward compatibility with the old label+prompt format.
  const labelPattern = /"label"\s*:\s*"([^"]+)"/g;
  while ((match = labelPattern.exec(text)) && items.length < 5) {
    const prompt = match[1]?.trim();
    if (prompt) items.push({ prompt });
  }

  return items;
}

function normalizePayload(parsed) {
  if (!parsed || typeof parsed !== "object") return null;

  if (parsed.codex_follow_up === true && Array.isArray(parsed.items)) {
    return {
      title: parsed.title || "Follow-up",
      items: parsed.items,
    };
  }

  if (parsed.soren_radar === true && Array.isArray(parsed.follow_ups)) {
    return {
      title: parsed.title || "Follow-up",
      items: parsed.follow_ups,
    };
  }

  return null;
}

function normalizeFollowupItem(item) {
  if (item && typeof item === "object") {
    const prompt = String(item.prompt || item.query || item.label || item.text || item.title || "").trim();
    return { prompt };
  }

  const prompt = String(item || "").trim();
  return { prompt };
}

function cleanPanelTitle(value, fallback) {
  const title = String(value || fallback || "Follow-up").trim();
  if (!title || /radar|soren/i.test(title)) return fallback || "Follow-up";
  return title;
}

function hideSourceBlock(code, markdown, rawText) {
  const block = findCodeBlockShell(code, markdown, rawText) || code.closest("pre") || code;
  if (!(block instanceof HTMLElement)) return;
  block.setAttribute(HIDDEN_ATTR, "true");
  block.hidden = true;
  block.style.setProperty("display", "none", "important");
}

function findCodeBlockShell(code, markdown, rawText) {
  const wanted = normalizeText(rawText);
  let current = code.closest("pre") || code;
  let best = current;

  while (current?.parentElement && current.parentElement !== markdown) {
    const parent = current.parentElement;
    const parentText = normalizeText(parent.textContent || "");
    const withoutLanguage = parentText.replace(/^json\s+/i, "");

    if (parentText === wanted || withoutLanguage === wanted || parentText.endsWith(wanted)) {
      best = parent;
      current = parent;
      continue;
    }

    break;
  }

  return best;
}

function normalizeText(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function renderRadarPanel({ title, items, showDivider, clickableItems, pending }) {
  const wrap = document.createElement("section");
  wrap.setAttribute(PANEL_ATTR, "true");
  wrap.className = "soren-radar-panel";

  if (showDivider) {
    const divider = document.createElement("div");
    divider.className = "soren-radar-divider";
    wrap.appendChild(divider);
  }

  const heading = document.createElement("div");
  heading.className = "soren-radar-title";
  heading.textContent = title || "Follow-up";
  wrap.appendChild(heading);

  const list = document.createElement("div");
  list.className = "soren-radar-list";
  const visibleItems = items.length > 0
    ? items
    : pending
      ? [{ prompt: "Preparing follow-up..." }]
      : [];

  for (const item of visibleItems) {
    const canClick = clickableItems && !pending && item.prompt;
    const row = document.createElement(canClick ? "button" : "div");
    row.className = canClick
      ? "soren-radar-row soren-radar-row-clickable"
      : "soren-radar-row";
    if (canClick) {
      row.type = "button";
      row.title = "Insert follow-up";
      row.addEventListener("click", () => insertIntoComposer(item.prompt));
    }

    const text = document.createElement("span");
    text.className = "soren-radar-text";
    text.textContent = item.prompt;
    if (pending && items.length === 0) {
      text.classList.add("soren-radar-text-pending");
    }

    row.appendChild(text);
    list.appendChild(row);
  }
  wrap.appendChild(list);
  return wrap;
}

function insertIntoComposer(text) {
  const value = String(text || "").trim();
  if (!value) return;

  const textarea = document.querySelector("textarea");
  if (textarea instanceof HTMLTextAreaElement) {
    textarea.focus();
    textarea.value = value;
    textarea.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
    return;
  }

  const editable = document.querySelector('[contenteditable="true"]');
  if (editable instanceof HTMLElement) {
    editable.focus();
    editable.textContent = value;
    editable.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
    return;
  }

  navigator.clipboard?.writeText(value).catch(() => {});
}

function clearPanels() {
  document.querySelectorAll(`[${PANEL_ATTR}]`).forEach((node) => node.remove());
  document.querySelectorAll(`[${HIDDEN_ATTR}]`).forEach((node) => {
    node.hidden = false;
    node.removeAttribute(HIDDEN_ATTR);
    node.style.removeProperty("display");
  });
}

function injectStyles() {
  if (document.getElementById(STYLE_ID)) return;
  const style = document.createElement("style");
  style.id = STYLE_ID;
  style.textContent = `
    .soren-radar-panel {
      margin-top: 14px;
      color: var(--text-primary, #f4f4f5);
      font-size: 13px;
      line-height: 1.45;
    }

    .soren-radar-divider {
      height: 1px;
      margin: 0 0 12px;
      background: color-mix(in srgb, currentColor 9%, transparent);
    }

    .soren-radar-title {
      margin-bottom: 8px;
      font-size: 12px;
      font-weight: 650;
      color: var(--text-primary, #f4f4f5);
    }

    .soren-radar-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .soren-radar-row {
      width: 100%;
      border: 0;
      background: transparent;
      padding: 0;
      display: block;
      color: var(--text-secondary, #a1a1aa);
      font: inherit;
      text-align: left;
    }

    .soren-radar-row-clickable {
      cursor: pointer;
      border-radius: 6px;
      margin-left: -3px;
      padding: 2px 3px;
      transition: background-color 120ms ease, color 120ms ease;
    }

    .soren-radar-row-clickable:hover {
      color: var(--text-primary, #f4f4f5);
      background: color-mix(in srgb, currentColor 7%, transparent);
    }

    .soren-radar-text {
      min-width: 0;
      overflow-wrap: anywhere;
    }

    .soren-radar-text-pending {
      opacity: 0.7;
      font-style: italic;
    }
  `;
  document.head.appendChild(style);
}

function renderSettings(root, state) {
  state.statusEl = null;

  root.appendChild(settingsSection("Behavior", [
    toggleRow({
      label: "Enable Follow-up",
      description: "Render structured follow-up payloads under assistant messages.",
      checked: state.enabled,
      onChange: (checked) => {
        state.enabled = checked;
        state.api.storage.set("enabled", checked);
        if (checked) state.scheduleScan?.();
        else clearPanels();
      },
    }),
    toggleRow({
      label: "Show divider",
      description: "Add a thin separator above the Follow-up panel.",
      checked: state.showDivider,
      onChange: (checked) => {
        state.showDivider = checked;
        state.api.storage.set("showDivider", checked);
        state.scheduleScan?.();
      },
    }),
    toggleRow({
      label: "Clickable items",
      description: "Click a follow-up item to insert its prompt into the composer.",
      checked: state.clickableItems,
      onChange: (checked) => {
        state.clickableItems = checked;
        state.api.storage.set("clickableItems", checked);
        state.scheduleScan?.();
      },
    }),
  ]));

  root.appendChild(settingsSection("Follow-up Instructions", [
    toggleRow({
      label: "Sync AGENTS.md instruction",
      description: "Keep a managed follow-up instruction block in the global Codex memory.",
      checked: state.syncAgents,
      onChange: async (checked) => {
        state.syncAgents = checked;
        state.api.storage.set("syncAgents", checked);
        await syncAgentsInstruction(state);
      },
    }),
    textareaRow({
      label: "Editable prompt",
      description: "Describe when follow-ups should appear. The JSON format is locked below.",
      value: state.followupPrompt,
      onInput: (value) => {
        state.followupPrompt = value;
        state.api.storage.set("followupPrompt", value);
      },
    }),
    lockedFormatRow(),
    actionRow({
      onApply: () => syncAgentsInstruction(state),
      onReset: async () => {
        state.followupPrompt = DEFAULT_FOLLOWUP_PROMPT;
        state.api.storage.set("followupPrompt", DEFAULT_FOLLOWUP_PROMPT);
        await syncAgentsInstruction(state);
        rerenderSettingsPage(root, state);
      },
      statusRef: (el) => {
        state.statusEl = el;
      },
    }),
  ]));
}

function rerenderSettingsPage(root, state) {
  while (root.firstChild) root.firstChild.remove();
  renderSettings(root, state);
}

async function syncAgentsInstruction(state, options = {}) {
  if (!state.api.ipc?.invoke) {
    setStatus(state, "IPC unavailable");
    return null;
  }

  try {
    if (!options.quiet) setStatus(state, "Syncing...");
    const result = await state.api.ipc.invoke(IPC_SYNC_AGENTS, {
      enabled: state.syncAgents,
      prompt: state.followupPrompt,
    });

    if (result?.ok) {
      const label =
        result.action === "removed"
          ? "Instruction removed"
          : result.action === "unchanged"
            ? "AGENTS.md already current"
            : "AGENTS.md updated";
      setStatus(state, label);
    } else {
      setStatus(state, result?.error || "Sync failed");
    }

    return result;
  } catch (error) {
    setStatus(state, error?.message || String(error));
    return null;
  }
}

function setStatus(state, text) {
  if (!state.statusEl) return;
  state.statusEl.textContent = text || "";
}

function settingsSection(title, rows) {
  const section = document.createElement("section");
  section.className = "mb-4 flex flex-col gap-2";
  const heading = document.createElement("div");
  heading.className = "px-1 text-sm font-medium text-token-text-primary";
  heading.textContent = title;
  section.appendChild(heading);
  const card = document.createElement("div");
  card.className =
    "divide-y divide-token-border-light rounded-xl border border-token-border-light bg-token-bg-primary";
  for (const row of rows) card.appendChild(row);
  section.appendChild(card);
  return section;
}

function toggleRow({ label, description, checked, onChange }) {
  const row = document.createElement("label");
  row.className = "flex cursor-pointer items-center justify-between gap-4 p-3";
  const left = document.createElement("div");
  left.className = "flex min-w-0 flex-col gap-1";
  const title = document.createElement("div");
  title.className = "text-sm text-token-text-primary";
  title.textContent = label;
  const desc = document.createElement("div");
  desc.className = "text-sm text-token-text-secondary";
  desc.textContent = description;
  left.appendChild(title);
  left.appendChild(desc);

  const input = document.createElement("input");
  input.type = "checkbox";
  input.checked = checked;
  input.className = "h-4 w-4";
  input.addEventListener("change", () => onChange(input.checked));

  row.appendChild(left);
  row.appendChild(input);
  return row;
}

function textareaRow({ label, description, value, onInput }) {
  const row = document.createElement("div");
  row.className = "flex flex-col gap-2 p-3";
  const title = document.createElement("div");
  title.className = "text-sm text-token-text-primary";
  title.textContent = label;
  const desc = document.createElement("div");
  desc.className = "text-sm text-token-text-secondary";
  desc.textContent = description;
  const textarea = document.createElement("textarea");
  textarea.className =
    "min-h-56 w-full resize-y rounded-lg border border-token-border-light bg-token-bg-secondary p-3 font-mono text-xs text-token-text-primary outline-none";
  textarea.spellcheck = false;
  textarea.value = value || "";
  textarea.addEventListener("input", () => onInput(textarea.value));
  row.appendChild(title);
  row.appendChild(desc);
  row.appendChild(textarea);
  return row;
}

function lockedFormatRow() {
  const row = document.createElement("details");
  row.className = "p-3";

  const summary = document.createElement("summary");
  summary.className = "cursor-pointer text-sm text-token-text-primary";
  summary.textContent = "Locked format";

  const desc = document.createElement("div");
  desc.className = "mt-2 text-sm text-token-text-secondary";
  desc.textContent = "This section is synced after the editable prompt and should not be modified in AGENTS.md.";

  const pre = document.createElement("pre");
  pre.className =
    "mt-3 max-h-64 overflow-auto rounded-lg border border-token-border-light bg-token-bg-secondary p-3 text-xs text-token-text-secondary";
  pre.textContent = LOCKED_FORMAT_INSTRUCTION;

  row.appendChild(summary);
  row.appendChild(desc);
  row.appendChild(pre);
  return row;
}

function actionRow({ onApply, onReset, statusRef }) {
  const row = document.createElement("div");
  row.className = "flex flex-wrap items-center justify-between gap-3 p-3";

  const status = document.createElement("div");
  status.className = "min-h-5 text-sm text-token-text-secondary";
  statusRef(status);

  const actions = document.createElement("div");
  actions.className = "flex items-center gap-2";

  const reset = document.createElement("button");
  reset.type = "button";
  reset.className =
    "rounded-lg border border-token-border-light px-3 py-2 text-sm text-token-text-secondary hover:bg-token-bg-secondary";
  reset.textContent = "Reset default";
  reset.addEventListener("click", onReset);

  const apply = document.createElement("button");
  apply.type = "button";
  apply.className =
    "rounded-lg border border-token-border-light bg-token-bg-secondary px-3 py-2 text-sm text-token-text-primary hover:bg-token-bg-tertiary";
  apply.textContent = "Apply to AGENTS.md";
  apply.addEventListener("click", onApply);

  actions.appendChild(reset);
  actions.appendChild(apply);
  row.appendChild(status);
  row.appendChild(actions);
  return row;
}

function createAgentsSyncService(api) {
  return {
    getAgentsPath,
    syncAgentsInstruction(settings = {}) {
      const enabled = settings.enabled !== false;
      const instruction = composeAgentsInstruction(settings.prompt);
      const agentsPath = getAgentsPath();

      try {
        const fs = require("fs");
        const current = fs.existsSync(agentsPath)
          ? fs.readFileSync(agentsPath, "utf8")
          : "";
        const next = enabled
          ? upsertManagedBlock(current, instruction)
          : removeManagedBlock(current);

        if (next === current) {
          return { ok: true, action: "unchanged", path: agentsPath };
        }

        fs.mkdirSync(require("path").dirname(agentsPath), { recursive: true });
        fs.writeFileSync(agentsPath, next, "utf8");
        return {
          ok: true,
          action: enabled ? "updated" : "removed",
          path: agentsPath,
        };
      } catch (error) {
        api.log.error("Codex Follow-up AGENTS.md sync failed", error);
        return {
          ok: false,
          error: error?.message || String(error),
          path: agentsPath,
        };
      }
    },
  };
}

function getAgentsPath() {
  const path = require("path");
  const os = require("os");
  const codexHome = process.env.CODEX_HOME || path.join(os.homedir(), ".codex");
  return path.join(codexHome, "AGENTS.md");
}

function normalizeInstruction(value) {
  const text = String(value || "").trim();
  return text || DEFAULT_FOLLOWUP_PROMPT;
}

function composeAgentsInstruction(prompt) {
  return [normalizeInstruction(prompt), LOCKED_FORMAT_INSTRUCTION].join("\n\n");
}

function migrateOldInstruction(value) {
  const text = String(value || "").trim();
  if (!text) return DEFAULT_FOLLOWUP_PROMPT;
  if (text.includes("soren_radar") || /radar\s+follow-ups/i.test(text)) {
    return DEFAULT_FOLLOWUP_PROMPT;
  }
  return text;
}

function migrateTitle(value) {
  const title = String(value || "").trim();
  if (!title || /radar|seguimiento|soren/i.test(title)) return "Follow-up";
  return title;
}

function upsertManagedBlock(source, instruction) {
  const block = [BLOCK_BEGIN, instruction.trim(), BLOCK_END].join("\n");
  const pattern = managedBlockPattern(BLOCK_BEGIN, BLOCK_END);
  const legacyPattern = managedBlockPattern(LEGACY_BLOCK_BEGIN, LEGACY_BLOCK_END);
  const oldestPattern = managedBlockPattern(OLDEST_BLOCK_BEGIN, OLDEST_BLOCK_END);
  const withoutLegacy = source
    .replace(managedBlockPattern(LEGACY_BLOCK_BEGIN, LEGACY_BLOCK_END, true), "\n")
    .replace(managedBlockPattern(OLDEST_BLOCK_BEGIN, OLDEST_BLOCK_END, true), "\n");

  if (pattern.test(withoutLegacy)) {
    return withoutLegacy.replace(pattern, block).replace(/\n{3,}/g, "\n\n");
  }

  if (legacyPattern.test(source)) {
    return source.replace(legacyPattern, block).replace(/\n{3,}/g, "\n\n");
  }

  if (oldestPattern.test(source)) {
    return source.replace(oldestPattern, block).replace(/\n{3,}/g, "\n\n");
  }

  const trimmed = withoutLegacy.replace(/\s+$/u, "");
  return `${trimmed}${trimmed ? "\n\n" : ""}${block}\n`;
}

function removeManagedBlock(source) {
  return source
    .replace(managedBlockPattern(BLOCK_BEGIN, BLOCK_END, true), "\n")
    .replace(managedBlockPattern(LEGACY_BLOCK_BEGIN, LEGACY_BLOCK_END, true), "\n")
    .replace(managedBlockPattern(OLDEST_BLOCK_BEGIN, OLDEST_BLOCK_END, true), "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trimEnd() + "\n";
}

function managedBlockPattern(begin, end, includeOuterWhitespace = false) {
  const prefix = includeOuterWhitespace ? "\\n*" : "";
  const suffix = includeOuterWhitespace ? "\\n*" : "";
  return new RegExp(`${prefix}${escapeRegExp(begin)}[\\s\\S]*?${escapeRegExp(end)}${suffix}`, "m");
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
